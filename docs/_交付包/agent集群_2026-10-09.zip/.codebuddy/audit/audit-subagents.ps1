<#
.SYNOPSIS
  子 agent 集群合规审计（结构 / 契约 / 越界 / 覆盖率 / 必备要素）。
.DESCRIPTION
  规则依据：RimWorld Mod Engineering Standard v3.0
    AI-001 任务入口 · AI-009 Gate 协议 · AI-011 违规分级 · GOV-012（不得绕过 Gate / 不得伪造 PASS）
    GOV-013 / ANNO-001 / REL-013（变更标注）· GATE-DELTA
  对 .codebuddy/agents/*.md 逐个校验：
    1) 结构：YAML front matter 存在 + name/description 齐备 + 正文非空
    2) 契约：ROLE / OWNED_GATES / FORBIDDEN_GATES 与预期映射一致（防越界）
    3) 覆盖：10 道 Gate 全覆盖且无重复归属（防漏派 / 重复派）
    4) 要素：references/ 分册引用、Evidence、GOV-012、Tier、落盘目录、AI-001、工具链登记册
  未登记在预期映射中的 agent 一律 BLOCKED（防止绕开审计自建 agent）。
  默认仅出报告（exit 0）；-Blocking 时存在 BLOCKED 则退出码 2。
.PARAMETER AgentsDir
  agent 定义目录，默认由脚本位置推导为 <工程根>/.codebuddy/agents
.PARAMETER OutFile
  可选：把审计结果写成 Gate Record markdown（落盘留证）
.PARAMETER Blocking
  存在 BLOCKED 时以退出码 2 结束（供 Orchestrator 派发前置钩子使用）
.EXAMPLE
  pwsh .codebuddy/audit/audit-subagents.ps1
  pwsh .codebuddy/audit/audit-subagents.ps1 -Blocking -OutFile .codebuddy/audit/gate-records/GR-AUDIT-AGENTS.md
#>
param(
    [string]$AgentsDir,
    [string]$OutFile,
    [switch]$Blocking
)

$ErrorActionPreference = 'Stop'

# ---------- 0. 定位与常量 ----------
if (-not $AgentsDir) {
    $projRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    $AgentsDir = Join-Path $projRoot '.codebuddy/agents'
}
if (-not (Test-Path -LiteralPath $AgentsDir)) { throw "agents 目录不存在: $AgentsDir" }
$AgentsDir = (Resolve-Path -LiteralPath $AgentsDir).Path

$allGates = @('ARCH', 'DATA', 'SAVE', 'LOC', 'UI', 'COMP', 'TEST', 'PERF', 'REL', 'DELTA')

# 预期映射 = 集群分工的唯一裁决源（见 .codebuddy/audit/subagent-audit-checklist.md §0）
$expected = [ordered]@{
    'pc-orchestrator.md'    = @{ Role = 'ORCHESTRATOR'; Name = 'pc-orchestrator';    Gates = @() }
    'pc-arch-gatekeeper.md' = @{ Role = 'GATE-AGENT';   Name = 'pc-arch-gatekeeper'; Gates = @('ARCH') }
    'pc-data-steward.md'    = @{ Role = 'GATE-AGENT';   Name = 'pc-data-steward';    Gates = @('DATA', 'SAVE') }
    'pc-ui-loc-guard.md'    = @{ Role = 'GATE-AGENT';   Name = 'pc-ui-loc-guard';    Gates = @('UI', 'LOC') }
    'pc-compat-auditor.md'  = @{ Role = 'GATE-AGENT';   Name = 'pc-compat-auditor';  Gates = @('COMP') }
    'pc-perf-tester.md'     = @{ Role = 'GATE-AGENT';   Name = 'pc-perf-tester';     Gates = @('PERF', 'TEST') }
    'pc-release-clerk.md'   = @{ Role = 'GATE-AGENT';   Name = 'pc-release-clerk';   Gates = @('REL', 'DELTA') }
}

# 通用必备要素（每个 agent 都必须命中的字面量）
$baseLiterals = @(
    @{ Key = 'AI-001';                          Desc = 'AI-001 任务入口协议' }
    @{ Key = 'GOV-012';                         Desc = 'GOV-012 不得绕过 / 不得伪造' }
    @{ Key = 'Tier';                            Desc = 'Tier A/B/C 降级' }
    @{ Key = 'Evidence';                        Desc = '证据要求' }
    @{ Key = 'references/';                     Desc = '规范分册引用' }
    @{ Key = '.codebuddy/audit/gate-records/';  Desc = '落盘输出目录' }
    @{ Key = 'toolchain-registry.md';           Desc = '本机工具链登记册引用（工具事实 SSOT）' }
    @{ Key = 'doc-standard';                    Desc = '文档产出规范引用（DOC-001~DOC-010：不得私自建文档）' }
)

# 专项必备要素（按 agent 追加）
$extraLiterals = @{
    'pc-orchestrator.md'    = @('AI-012', 'gate-runner.ps1', 'EXC', 'audit-subagents.ps1')
    'pc-arch-gatekeeper.md' = @('GATE-ARCH', 'ARC-013')
    'pc-data-steward.md'    = @('DATA-001', 'SAVE-001')
    'pc-ui-loc-guard.md'    = @('UI-001', 'LOC-001')
    'pc-compat-auditor.md'  = @('COMP-001')
    'pc-perf-tester.md'     = @('PERF-001', 'TEST-001')
    'pc-release-clerk.md'   = @('REL-001', 'ANNO-001', 'gate-runner.ps1', 'Changelog')
}

# Gate -> 关联规则 ID（供报告追溯）
$gateRules = @{
    'ARCH'  = 'GOV-001/MATRIX-001/ARC-001/ARC-013'
    'DATA'  = 'DATA-001/DATA-004/SAVE-001'
    'SAVE'  = 'SAVE-001/SAVE-004'
    'LOC'   = 'LOC-001/LOC-004/COMP-007'
    'UI'    = 'UI-001/ASSET-001/PERF-002'
    'COMP'  = 'COMP-001/COMP-004'
    'TEST'  = 'TEST-001'
    'PERF'  = 'PERF-001/PERF-003'
    'REL'   = 'REL-001'
    'DELTA' = 'GOV-013/ANNO-001/REL-013'
}

# 已登记 skill 注册表（skill → agent 触发的白名单）
# 新增 skill 必须：① 加入本表（并同步 route-task.ps1 同名表，双源交叉校验见 §1 前段）
#                  ② 至少被一个 GATE-AGENT 的 SKILLS 行声明
$knownSkills = @('RimWorld工程架构规范', 'RimWorld模组开发知识库', 'RimWorld组件绘制', 'RimWorld程序集API静态核实', 'summarize', 'change-report', 'ai-bug-engineering', 'memory-standard', 'doc-standard')

function Get-ContractValue {
    param([string]$Text, [string]$Key)
    $m = [regex]::Match($Text, "(?m)^\s*$Key\s*:\s*(.+?)\s*$")
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    return $null
}

function Parse-GateSet {
    param([string]$Raw)
    if ([string]::IsNullOrWhiteSpace($Raw) -or $Raw.Trim().ToUpperInvariant() -eq 'NONE') { return @() }
    return @($Raw.Split(',') | ForEach-Object { $_.Trim().ToUpperInvariant() } | Where-Object { $_ })
}

function Test-SetEqual {
    param([string[]]$A, [string[]]$B)
    $a = @($A | Sort-Object -Unique)
    $b = @($B | Sort-Object -Unique)
    if ($a.Count -ne $b.Count) { return $false }
    for ($i = 0; $i -lt $a.Count; $i++) { if ($a[$i] -ne $b[$i]) { return $false } }
    return $true
}

# ---------- 1. 逐文件审计 ----------
$rowObjs = [System.Collections.Generic.List[object]]::new()
$problems = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()
$gateOwners = @{}
$triggerOwners = @{}
$skillOwners = @{}
$blockedCount = 0
$passCount = 0

# 双源一致性：route-task.ps1 的 $knownSkills 必须与本脚本一致（改一处忘另一处 ⇒ 路由/审计结论分歧）
$crossSourceOk = $true
$routeScriptPath = Join-Path $PSScriptRoot 'route-task.ps1'
if (Test-Path -LiteralPath $routeScriptPath) {
    $routeText = Get-Content -LiteralPath $routeScriptPath -Raw -Encoding UTF8
    $km = [regex]::Match($routeText, '(?m)^\s*\$knownSkills\s*=\s*@\(([^)]*)\)')
    if (-not $km.Success) {
        $crossSourceOk = $false
        $problems.Add('[注册表双源] route-task.ps1 中未找到 $knownSkills 注册表行')
    }
    else {
        $routeSkills = @($km.Groups[1].Value -split ',' | ForEach-Object { ($_.Trim() -replace "'", '').Trim() } | Where-Object { $_ })
        $onlyHere = @($knownSkills | Where-Object { $routeSkills -notcontains $_ })
        $onlyThere = @($routeSkills | Where-Object { $knownSkills -notcontains $_ })
        if ($onlyHere.Count -gt 0 -or $onlyThere.Count -gt 0) {
            $crossSourceOk = $false
            $problems.Add("[注册表双源不一致] 仅 audit 有: $($onlyHere -join ',')；仅 route-task 有: $($onlyThere -join ',')")
        }
    }
}
else {
    $crossSourceOk = $false
    $problems.Add('[注册表双源] 未找到 route-task.ps1（无法交叉校验）')
}

$files = @(Get-ChildItem -LiteralPath $AgentsDir -Filter '*.md' -File | Sort-Object Name)

foreach ($f in $files) {
    $isRegistered = $expected.Contains($f.Name)
    $text = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8
    $lines = Get-Content -LiteralPath $f.FullName -Encoding UTF8
    $fails = [System.Collections.Generic.List[string]]::new()

    # --- 1.0 登记检查（未登记即不可派发） ---
    if (-not $isRegistered) {
        $fails.Add('未登记 agent：必须登记到 audit-subagents.ps1 预期映射后方可派发')
        $warnings.Add("检测到未登记 agent：$($f.Name)")
    }

    # --- 1.1 结构 ---
    $structOk = $true
    if ($lines.Count -lt 20) { $structOk = $false; $fails.Add('正文过短(<20行)') }
    if ($lines[0].Trim() -ne '---') { $structOk = $false; $fails.Add('缺 YAML front matter') }
    else {
        $close = -1
        for ($i = 1; $i -lt [Math]::Min(12, $lines.Count); $i++) { if ($lines[$i].Trim() -eq '---') { $close = $i; break } }
        if ($close -lt 0) { $structOk = $false; $fails.Add('front matter 未闭合') }
        else {
            $fm = ($lines[1..($close - 1)]) -join "`n"
            if ($fm -notmatch '(?m)^\s*name\s*:\s*\S+') { $structOk = $false; $fails.Add('front matter 缺 name') }
            if ($fm -notmatch '(?m)^\s*description\s*:\s*\S+') { $structOk = $false; $fails.Add('front matter 缺 description') }
            if ($isRegistered) {
                $declaredName = Get-ContractValue -Text $fm -Key 'name'
                if ($declaredName -ne $expected[$f.Name].Name) { $structOk = $false; $fails.Add("name 与文件名不符($declaredName)") }
            }
        }
    }

    # --- 1.2 契约（角色 / 归属 / 禁区） ---
    $contractOk = $true
    $role = Get-ContractValue -Text $text -Key 'ROLE'
    $ownedRaw = Get-ContractValue -Text $text -Key 'OWNED_GATES'
    $forbidRaw = Get-ContractValue -Text $text -Key 'FORBIDDEN_GATES'

    if (-not $role) { $contractOk = $false; $fails.Add('缺 ROLE') }
    if (-not $ownedRaw) { $contractOk = $false; $fails.Add('缺 OWNED_GATES') }
    if (-not $forbidRaw) { $contractOk = $false; $fails.Add('缺 FORBIDDEN_GATES') }

    $owned = Parse-GateSet -Raw $ownedRaw
    $forbid = Parse-GateSet -Raw $forbidRaw

    if ($isRegistered) {
        $exp = $expected[$f.Name]
        if ($role -and $role -ne $exp.Role) { $contractOk = $false; $fails.Add("ROLE 应为 $($exp.Role)") }
        if ($ownedRaw -and -not (Test-SetEqual -A $owned -B $exp.Gates)) {
            $contractOk = $false
            $fails.Add("OWNED_GATES 越界/缺失(声明=$($owned -join ','); 预期=$($exp.Gates -join ','))")
        }
        if ($role -eq 'ORCHESTRATOR') {
            if ($forbidRaw -and $forbidRaw.Trim().ToUpperInvariant() -ne 'NONE') { $contractOk = $false; $fails.Add('总控 FORBIDDEN_GATES 应为 NONE') }
        }
        elseif ($role -eq 'GATE-AGENT') {
            $expectForbid = @($allGates | Where-Object { $owned -notcontains $_ })
            if ($forbidRaw -and -not (Test-SetEqual -A $forbid -B $expectForbid)) {
                $contractOk = $false
                $fails.Add("FORBIDDEN_GATES 与归属不互补(声明=$($forbid -join ','); 预期=$($expectForbid -join ','))")
            }
        }
    }

    # 归属重复检测
    foreach ($g in $owned) {
        if (-not $allGates.Contains($g)) { $contractOk = $false; $fails.Add("未知 Gate 名：$g"); continue }
        if ($gateOwners.ContainsKey($g)) {
            $contractOk = $false
            $fails.Add("Gate $g 重复归属（已被 $($gateOwners[$g]) 占用）")
        } else { $gateOwners[$g] = $f.Name }
    }

    # --- 1.3 必备要素 ---
    $elemOk = $true
    $missing = [System.Collections.Generic.List[string]]::new()
    foreach ($lit in $baseLiterals) {
        if ($text -notmatch [regex]::Escape($lit.Key)) { $missing.Add($lit.Desc) }
    }
    if ($isRegistered -and $extraLiterals.ContainsKey($f.Name)) {
        foreach ($k in $extraLiterals[$f.Name]) {
            if ($text -notmatch [regex]::Escape($k)) { $missing.Add("专项要素 $k") }
        }
    }
    if ($missing.Count -gt 0) { $elemOk = $false; foreach ($m in $missing) { $fails.Add("缺 $m") } }

    # --- 1.4 触发规则（自动调用契约） ---
    $triggerOk = $true
    $triggerRaw = Get-ContractValue -Text $text -Key 'TRIGGER_KEYWORDS'
    $noTriggerRaw = Get-ContractValue -Text $text -Key 'NO_TRIGGER'

    if (-not $triggerRaw) { $triggerOk = $false; $fails.Add('缺 TRIGGER_KEYWORDS') }
    if (-not $noTriggerRaw) { $triggerOk = $false; $fails.Add('缺 NO_TRIGGER') }

    $triggers = @()
    $noTriggers = @()
    if ($triggerRaw) {
        $triggers = @($triggerRaw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($triggers.Count -lt 3) { $triggerOk = $false; $fails.Add("TRIGGER_KEYWORDS 少于 3 项（当前 $($triggers.Count)）") }
    }
    if ($noTriggerRaw) {
        $noTriggers = @($noTriggerRaw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($noTriggers.Count -lt 1) { $triggerOk = $false; $fails.Add('NO_TRIGGER 为空') }
    }

    # C3：同一 agent 内 触发词 ∩ 不触发 == 空
    $selfClash = @($triggers | Where-Object { $noTriggers -contains $_ })
    if ($selfClash.Count -gt 0) { $triggerOk = $false; $fails.Add("自身触发词与不触发冲突：$($selfClash -join ',')") }

    # C2：触发词全局唯一（防自动调用路由二义）
    foreach ($kw in $triggers) {
        $k = $kw.ToLowerInvariant()
        if ($triggerOwners.ContainsKey($k)) {
            $triggerOk = $false
            $fails.Add("触发词二义：'$kw' 已被 $($triggerOwners[$k]) 占用")
        } else { $triggerOwners[$k] = $f.Name }
    }

    # --- 1.45 skill 触发契约（skill → agent） ---
    $skillOk = $true
    $skillRaw = Get-ContractValue -Text $text -Key 'SKILLS'
    $skills = @()
    if (-not $skillRaw) { $skillOk = $false; $fails.Add('缺 SKILLS') }
    else {
        $skills = @($skillRaw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        if ($skills.Count -lt 1) { $skillOk = $false; $fails.Add('SKILLS 为空') }
        foreach ($s in $skills) {
            if (-not $knownSkills.Contains($s)) {
                $skillOk = $false
                $fails.Add("未登记 skill 名：$s（须先加入脚本注册表并补文档）")
            }
            elseif ($role -eq 'GATE-AGENT') {
                # skill 覆盖只统计 Gate agent，避免总控“全声明”把覆盖检查架空
                if (-not $skillOwners.ContainsKey($s)) { $skillOwners[$s] = [System.Collections.Generic.List[string]]::new() }
                $skillOwners[$s].Add($f.Name)
            }
        }
    }

    # --- 1.5 结论 ---
    if ($structOk -and $contractOk -and $elemOk -and $triggerOk -and $skillOk) {
        $verdict = 'PASS'
        $passCount++
    } else {
        $verdict = 'BLOCKED'
        $blockedCount++
        foreach ($msg in $fails) { $problems.Add("[$($f.Name)] $msg") }
    }

    $rowObjs.Add([pscustomobject]@{
            File     = $f.Name
            Role     = if ($role) { $role } else { '<缺失>' }
            Gates    = if ($owned.Count -gt 0) { $owned -join ',' } else { 'NONE' }
            Struct   = if ($structOk) { 'OK' } else { 'FAIL' }
            Contract = if ($contractOk) { 'OK' } else { 'FAIL' }
            Elem     = if ($elemOk) { 'OK' } else { 'FAIL' }
            Trigger  = if ($triggerOk) { "OK($($triggers.Count))" } else { 'FAIL' }
            Skill    = if ($skillOk) { "OK($($skills.Count))" } else { 'FAIL' }
            Verdict  = $verdict
        })
}

# ---------- 2. 覆盖率（10/10 且无漏派） ----------
$coveredGates = @($allGates | Where-Object { $gateOwners.ContainsKey($_) })
$missingGates = @($allGates | Where-Object { -not $gateOwners.ContainsKey($_) })
$coverageOk = ($missingGates.Count -eq 0)

$missingFiles = @($expected.Keys | Where-Object { -not (Test-Path -LiteralPath (Join-Path $AgentsDir $_)) })
$fileSetOk = ($missingFiles.Count -eq 0)

# skill 覆盖：注册表里每个 skill 至少被一个 GATE-AGENT 声明（总控全声明不算数）
$missingSkillCoverage = @($knownSkills | Where-Object { -not $skillOwners.ContainsKey($_) })
$skillCoverageOk = ($missingSkillCoverage.Count -eq 0)

$overall = if ($blockedCount -eq 0 -and $coverageOk -and $fileSetOk -and $skillCoverageOk -and $crossSourceOk) { 'PASS' } else { 'BLOCKED' }

# ---------- 3. 报告 ----------
$now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$report = [System.Collections.Generic.List[string]]::new()
$report.Add('=== 子 agent 集群合规审计 ===')
$report.Add('规范: RimWorld Mod Engineering Standard v3.0  (AI-001/AI-009/AI-011/GOV-012/GOV-013/ANNO-001/GATE-DELTA)')
$report.Add("时间: $now")
$report.Add("目录: $AgentsDir")
$report.Add('')
$report.Add(('{0,-28} {1,-12} {2,-14} {3,-6} {4,-7} {5,-6} {6,-9} {7,-9} {8}' -f '文件', '角色', '归属Gate', '结构', '契约', '要素', '触发', '技能', '结论'))
$report.Add(('-' * 118))
foreach ($r in $rowObjs) {
    $report.Add(('{0,-28} {1,-12} {2,-14} {3,-6} {4,-7} {5,-6} {6,-9} {7,-9} {8}' -f $r.File, $r.Role, $r.Gates, $r.Struct, $r.Contract, $r.Elem, $r.Trigger, $r.Skill, $r.Verdict))
}
$report.Add('')
$report.Add("覆盖率: $($coveredGates.Count)/$($allGates.Count) -> $(if ($coverageOk) { 'OK' } else { 'MISSING: ' + ($missingGates -join ',') })")
$report.Add('Gate 归属: ' + (($allGates | ForEach-Object { "$_=$($gateOwners[$_])" }) -join '  '))
$report.Add("文件齐备: $(if ($fileSetOk) { 'OK' } else { 'MISSING: ' + ($missingFiles -join ',') })")
$report.Add("skill 覆盖: $($knownSkills.Count - $missingSkillCoverage.Count)/$($knownSkills.Count) -> $(if ($skillCoverageOk) { 'OK' } else { 'MISSING: ' + ($missingSkillCoverage -join ',') })")
$report.Add("注册表双源: $(if ($crossSourceOk) { 'OK（与 route-task.ps1 一致）' } else { 'MISMATCH（见问题）' })")
$report.Add('skill 响应: ' + (($knownSkills | ForEach-Object { "$_=" + $(if ($skillOwners.ContainsKey($_)) { ($skillOwners[$_] -join '+') } else { 'NONE' }) }) -join '  '))
if ($warnings.Count -gt 0) { $report.Add(''); $report.Add('警告:'); foreach ($w in $warnings) { $report.Add("  - $w") } }
if ($problems.Count -gt 0) { $report.Add(''); $report.Add('问题:'); foreach ($p in $problems) { $report.Add("  - $p") } }
$report.Add('')
$report.Add("结论: $overall  (PASS=$passCount / BLOCKED=$blockedCount / Gate覆盖=$($coveredGates.Count)/10 / skill覆盖=$($knownSkills.Count - $missingSkillCoverage.Count)/$($knownSkills.Count))")
$report.Add('规则: 任一 BLOCKED 阻止派发（GOV-012 不得绕过）；N/A 必须带理由，不得伪造 PASS。')

$reportText = ($report -join [Environment]::NewLine)
Write-Output $reportText

if ($OutFile) {
    $outDir = Split-Path -Parent $OutFile
    if ($outDir -and -not (Test-Path -LiteralPath $outDir)) { $null = New-Item -ItemType Directory -Path $outDir -Force }
    $md = [System.Collections.Generic.List[string]]::new()
    $md.Add('# Gate Record · 子 agent 集群合规审计')
    $md.Add('')
    $md.Add('- Change: AUDIT-AGENTS（子 agent 定义合规审计）')
    $md.Add("- Date: $now")
    $md.Add('- Reviewer: audit-subagents.ps1')
    $md.Add('- Scope: .codebuddy/agents/')
    $md.Add('- Rule IDs: AI-001 / AI-009 / AI-011 / GOV-012 / GOV-013 / ANNO-001 / GATE-DELTA')
    $md.Add('')
    $md.Add('| 文件 | 角色 | 归属 Gate | 结构 | 契约 | 要素 | 触发 | 技能 | 结论 |')
    $md.Add('|---|---|---|---|---|---|---|---|---|')
    foreach ($r in $rowObjs) {
        $md.Add("| $($r.File) | $($r.Role) | $($r.Gates) | $($r.Struct) | $($r.Contract) | $($r.Elem) | $($r.Trigger) | $($r.Skill) | $($r.Verdict) |")
    }
    $md.Add('')
    $md.Add('| Gate | 归属 Agent | 关联规则 ID |')
    $md.Add('|---|---|---|')
    foreach ($g in $allGates) { $md.Add("| $g | $($gateOwners[$g]) | $($gateRules[$g]) |") }
    $md.Add('')
    $md.Add('| Skill（注册表） | 响应的 Gate Agent |')
    $md.Add('|---|---|')
    foreach ($s in $knownSkills) {
        $sOwners = if ($skillOwners.ContainsKey($s)) { ($skillOwners[$s] -join ', ') } else { '<无 Gate agent 响应>' }
        $md.Add("| $s | $sOwners |")
    }
    $md.Add('')
    $md.Add("**结论**: $overall （覆盖率 $($coveredGates.Count)/10）")
    $md.Add('')
    if ($problems.Count -gt 0) {
        $md.Add('**问题**:')
        foreach ($p in $problems) { $md.Add("- $p") }
    } else { $md.Add('**问题**: 无') }
    $md.Add('')
    $md.Add('```text')
    $md.Add($reportText)
    $md.Add('```')
    Set-Content -LiteralPath $OutFile -Value ($md -join [Environment]::NewLine) -Encoding UTF8
    Write-Output "已写入 Gate Record: $OutFile"
}

if ($Blocking -and $overall -ne 'PASS') { exit 2 }
exit 0
