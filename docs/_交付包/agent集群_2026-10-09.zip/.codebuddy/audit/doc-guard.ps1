<#
.SYNOPSIS
  文档域门禁（DOC-001–DOC-010）—— 落点 / 增量 / front-matter / 索引 / 取代 / 相似度。
.DESCRIPTION
  规范正本：docs/设计文档/架构/12-文档与交付物治理规范.md（DOC-001~DOC-010）。
  机制：以 .codebuddy/audit/doc-baseline.json（文件系统快照：路径集合）冻结改动前存量，
        **只拦新增与新增引发的违规**；历史存量（含仓库根历史标注）在基线内不判违规。
  检查项：
    C1 仓库根出现新增文档类文件                 -> BLOCKED
    C2 docs 顶层出现新增文件（README.md 除外）  -> BLOCKED
    C3 新增文档 front-matter 缺失/非法（仅 docs/ 与仓库根） -> BLOCKED
    C4 status=supersede 时旧件未加"已被取代"横幅或仍在索引 -> BLOCKED
    C5 新增文档与存量主题相似度超阈值（疑似重复） -> WARN
    C6 新增文档未被主题 README / docs/README 收录 -> WARN（-Strict 时 BLOCKED）
  豁免：变更标注（变更标注_CHG-*、docs/设计文档/架构/变更标注/**）与 docs/changelog/** 走各自流程（GATE-DELTA / 发布规范）。
  基线刷新纪律：**仅存量收口轮次经用户确认可 -Rebaseline**；日常刷基线 = 绕过门禁（GOV-012）。
.NOTES
  mode  : 报告模式默认 exit 0；-Blocking 有 BLOCKED 时 exit 2；基线缺失 exit 1。
  用法  :
    pwsh .codebuddy\audit\doc-guard.ps1 -Find 经济      # DOC-003 存量检索
    pwsh .codebuddy\audit\doc-guard.ps1 -Blocking      # 交付终检
    pwsh .codebuddy\audit\doc-guard.ps1 -Strict        # WARN 升级为 BLOCKED
    pwsh .codebuddy\audit\doc-guard.ps1 -Rebaseline    # 刷新基线（仅存量收口轮次）
    pwsh .codebuddy\audit\doc-guard.ps1 -Blocking -ExcludeFromFile <清单>  # 声明范围外（并行在途/预存无关改动）
#>
param(
    [string]$Find,
    [switch]$Blocking,
    [switch]$Strict,
    [switch]$Rebaseline,
    [string]$ExcludeFromFile,
    [string]$Root
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8; $OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

if (-not $Root) { $Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path }
$rootFull = (Resolve-Path -LiteralPath $Root).Path
$baselinePath = Join-Path $PSScriptRoot 'doc-baseline.json'

$governedExts = @('.md', '.markdown', '.html', '.txt', '.rst')
# 受治理扫描根（相对工程根；'' = 仓库根，非递归）
$scanDirs = @('docs', '系统中心蓝图', '.codebuddy/skills', '.codebuddy/rules', '.codebuddy/agents', '.codebuddy/audit')
$excludeSegs = @('/.git/', '/node_modules/', '/.codebuddy/tmp/', '/.codebuddy/memory-journal/', '/.codebuddy/doc-journal/', '/.codebuddy/audit/gate-records/', '/.codebuddy/plans/', '/.codebuddy/teams/', '/.codebuddy/memory/')

Write-Host '=== 文档域门禁 doc-guard（DOC-001–DOC-010） ===' -ForegroundColor Cyan
Write-Host "工程根 : $rootFull"
Write-Host "基线   : $baselinePath"

function Test-ExcludedPath([string]$rel) {
    $seg = '/' + $rel
    foreach ($e in $excludeSegs) { if ($seg.StartsWith($e)) { return $true } }
    return $false
}

function Get-GovernedFiles {
    $list = New-Object System.Collections.Generic.List[string]
    # 仓库根（非递归，只看顶层文件）
    Get-ChildItem -LiteralPath $rootFull -File -ErrorAction SilentlyContinue | ForEach-Object {
        if ($governedExts -contains $_.Extension.ToLower()) { $list.Add($_.Name) }
    }
    foreach ($d in $scanDirs) {
        $p = Join-Path $rootFull ($d -replace '/', '\')
        if (-not (Test-Path -LiteralPath $p)) { continue }
        Get-ChildItem -LiteralPath $p -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            if ($governedExts -notcontains $_.Extension.ToLower()) { return }
            $rel = $_.FullName.Substring($rootFull.Length + 1) -replace '\\', '/'
            if (-not (Test-ExcludedPath $rel)) { $list.Add($rel) }
        }
    }
    return @($list | Sort-Object -Unique)
}

# ---------- -Find：DOC-003 存量检索 ----------
if ($Find) {
    Write-Host "--- 存量检索（DOC-003）：$Find ---" -ForegroundColor Yellow
    $all = Get-GovernedFiles
    $nameHits = @($all | Where-Object { $_ -like "*$Find*" })
    Write-Host "[文件名命中] $($nameHits.Count) 条"
    $nameHits | Select-Object -First 40 | ForEach-Object { Write-Host "  $_" }
    $contentHits = @()
    foreach ($f in ($all | Where-Object { $_.EndsWith('.md') })) {
        $full = Join-Path $rootFull ($f -replace '/', '\')
        $m = Select-String -LiteralPath $full -Pattern ([regex]::Escape($Find)) -SimpleMatch -List -ErrorAction SilentlyContinue
        if ($m) { $contentHits += $f }
    }
    Write-Host "[内容命中] $($contentHits.Count) 条（前 40）"
    $contentHits | Select-Object -First 40 | ForEach-Object { Write-Host "  $_" }
    Write-Host '提示：命中同主题存量 ⇒ 默认更新（DOC-003），不得另建新文件；确需新建须在申请中举证。' -ForegroundColor Yellow
    exit 0
}

# ---------- 基线读取 ----------
if (-not (Test-Path -LiteralPath $baselinePath)) {
    if (-not $Rebaseline) {
        Write-Host '基线缺失：请先执行 -Rebaseline（仅存量收口轮次，经用户确认）。' -ForegroundColor Red
        exit 1
    }
}
$baseSet = @{}
if (Test-Path -LiteralPath $baselinePath) {
    $bj = Get-Content -LiteralPath $baselinePath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($f in @($bj.files)) { $baseSet[$f] = $true }
    Write-Host "基线时间：$($bj.generatedAt)  文件数：$($bj.files.Count)"
}

$files = Get-GovernedFiles
Write-Host "受治理文件总数：$($files.Count)"

if ($Rebaseline) {
    $obj = [ordered]@{
        generatedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        note        = 'DOC-010 基线：冻结存量、只拦新增；仅存量收口轮次经用户确认可刷新'
        files       = @($files)
    }
    $obj | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $baselinePath -Encoding UTF8
    Write-Host "基线已刷新：$baselinePath（$($files.Count) 个文件）" -ForegroundColor Green
    exit 0
}

$excludeSet = @{}
if ($ExcludeFromFile) {
    if (-not (Test-Path -LiteralPath $ExcludeFromFile)) {
        Write-Host "范围外清单不存在：$ExcludeFromFile" -ForegroundColor Red
        exit 1
    }
    foreach ($ln in (Get-Content -LiteralPath $ExcludeFromFile -Encoding UTF8)) {
        $t = ($ln -replace '\\', '/').Trim()
        if (-not $t -or $t.StartsWith('#')) { continue }
        $excludeSet[$t] = $true
    }
    Write-Host "范围外声明：$($excludeSet.Count) 条（-ExcludeFromFile）"
}
$addedAll = @($files | Where-Object { -not $baseSet.ContainsKey($_) })
$excludedHits = @($addedAll | Where-Object { $excludeSet.ContainsKey($_) })
$added = @($addedAll | Where-Object { -not $excludeSet.ContainsKey($_) })
if ($excludedHits.Count -gt 0) {
    Write-Host "范围外（不判违规，仅登记）$($excludedHits.Count) 条：" -ForegroundColor DarkYellow
    $excludedHits | ForEach-Object { Write-Host "  - $_" -ForegroundColor DarkYellow }
}
Write-Host "相对基线的新增文件：$($added.Count)（范围外 $($excludedHits.Count) 不计）"

# ---------- 辅助函数 ----------
function Get-DocField {
    param([string[]]$Head, [string]$Key)
    foreach ($line in $Head) {
        if ($line -match ("(?i)^\s*(?:>|\*|-|\s)*" + [regex]::Escape($Key) + "\s*[:：]\s*(.+?)\s*$")) {
            return $Matches[1].Trim()
        }
    }
    return $null
}

function Get-DocTitle {
    param([string[]]$Head, [string]$Fallback)
    foreach ($line in $Head) {
        if ($line -match '^\s*#\s+(.+?)\s*$') { return $Matches[1].Trim() }
    }
    return $Fallback
}

function Get-Grams {
    param([string]$Text)
    $t = ($Text -replace '[\s\p{P}·—\-_\[\]（）()]+', '')
    $set = New-Object System.Collections.Generic.HashSet[string]
    if ($t.Length -lt 2) { if ($t.Length -eq 1) { $null = $set.Add($t) }; return $set }
    for ($i = 0; $i -lt $t.Length - 1; $i++) { $null = $set.Add($t.Substring($i, 2)) }
    return $set
}

function Jaccard {
    param($A, $B)
    if ($A.Count -eq 0 -or $B.Count -eq 0) { return 0.0 }
    $inter = 0
    foreach ($x in $A) { if ($B.Contains($x)) { $inter++ } }
    $union = $A.Count + $B.Count - $inter
    if ($union -le 0) { return 0.0 }
    return [double]$inter / $union
}

function Get-NameStem([string]$rel) {
    $leaf = Split-Path $rel -Leaf
    $stem = [System.IO.Path]::GetFileNameWithoutExtension($leaf)
    $stem = $stem -replace '^\d+[-_]?', ''
    $stem = $stem -replace '\d{4}-\d{2}-\d{2}', ''
    $stem = $stem -replace 'CHG-?\d+', ''
    return $stem
}

function Test-ExemptFlow([string]$rel) {
    if ($rel -match '变更标注_CHG-|^docs/设计文档/架构/变更标注/|^docs/changelog/') { return $true }
    return $false
}

# ---------- 逐项检查 ----------
$blocked = New-Object System.Collections.Generic.List[string]
$warns = New-Object System.Collections.Generic.List[string]

# 存量索引缓存（供 C4 / C6）
$readmeCache = @{}
function Get-IndexText([string]$dirRel) {
    if ($readmeCache.ContainsKey($dirRel)) { return $readmeCache[$dirRel] }
    $txt = ''
    $p = Join-Path $rootFull ((($dirRel.TrimEnd('/')) + '/README.md') -replace '/', '\')
    if (Test-Path -LiteralPath $p) { $txt = Get-Content -LiteralPath $p -Raw -Encoding UTF8 }
    $readmeCache[$dirRel] = $txt
    return $txt
}

foreach ($f in $added) {
    $full = Join-Path $rootFull ($f -replace '/', '\')
    $isRootLevel = ($f -notmatch '/')
    $isDocsTop = ($f -match '^docs/[^/]+$') -and ($f -notmatch '^docs/README\.md$')

    # C1 / C2 落点
    if ($isRootLevel) {
        $blocked.Add("C1 仓库根新增文档：$f ｜ 落点唯一：按 docs/README.md 用途判定表落位（DOC-001）")
        continue
    }
    if ($isDocsTop) {
        $blocked.Add("C2 docs 顶层新增文件：$f ｜ docs 顶层只允许 README.md（DOC-001）")
        continue
    }

    if (Test-ExemptFlow $f) {
        Write-Host "  [豁免流程] $f（变更标注 / Changelog：由 GATE-DELTA / 06 发布规范管辖）"
        continue
    }

    $head = @()
    if (Test-Path -LiteralPath $full) { $head = @(Get-Content -LiteralPath $full -TotalCount 40 -Encoding UTF8) }

    # C3 front-matter（仅 docs/ 与仓库根；.codebuddy/** 有自己的契约，不检）
    if ($f -match '^docs/') {
        $docId = Get-DocField $head 'doc-id'
        $status = Get-DocField $head 'status'
        $supersedes = Get-DocField $head 'supersedes'
        $approved = Get-DocField $head 'approved'
        $author = Get-DocField $head 'author'
        $miss = @()
        if (-not $docId) { $miss += 'doc-id' }
        if (-not $status) { $miss += 'status' }
        if (-not $supersedes) { $miss += 'supersedes' }
        if (-not $author) { $miss += 'author' }
        if ($status -and $status.ToLowerInvariant() -notin @('new', 'update', 'supersede')) { $miss += "status 取值非法($status)" }
        if ($status -and $status.ToLowerInvariant() -ne 'update' -and -not $approved) { $miss += 'approved' }
        if ($status -and $status.ToLowerInvariant() -eq 'supersede' -and (($supersedes -eq '—') -or ($supersedes -eq '-'))) { $miss += 'supersedes 为空' }
        if ($miss.Count -gt 0) {
            $blocked.Add("C3 front-matter 缺/非法 [$($miss -join ', ')]：$f（DOC-005）")
            continue
        }

        # C4 取代处置
        if ($status -and $status.ToLowerInvariant() -eq 'supersede' -and $supersedes -and $supersedes -notin @('—', '-')) {
            $oldRel = $supersedes -replace '\\', '/'
            $oldFull = Join-Path $rootFull ($oldRel -replace '/', '\')
            $oldLeaf = Split-Path $oldRel -Leaf
            if (Test-Path -LiteralPath $oldFull) {
                $oldHead = @(Get-Content -LiteralPath $oldFull -TotalCount 12 -Encoding UTF8)
                if (-not ($oldHead -join "`n" -match '已被取代')) {
                    $blocked.Add("C4 旧件未加「已被取代」横幅：$oldRel（DOC-007）")
                }
            }
            else {
                $warns.Add("C4 supersedes 指向的旧件不在原位（可能已归档，请确认）：$oldRel")
            }
            $dir = Split-Path $f -Parent
            $idxHit = $false
            foreach ($d in @('.', 'docs', 'docs/设计文档', 'docs/设计文档/架构', $dir)) {
                $t = Get-IndexText $d
                if ($t -and $t.Contains($oldLeaf)) { $idxHit = $true; break }
            }
            if ($idxHit) { $blocked.Add("C4 旧件仍出现在索引入口：$oldLeaf（DOC-007 禁止双源并存）") }
        }
    }

    # C5 相似度（疑似重复 → 更新优先）
    $title = Get-DocTitle $head (Get-NameStem $f)
    $newG = Get-Grams $title
    if ($newG.Count -ge 4) {
        $best = 0.0; $bestRel = ''
        foreach ($b in $baseSet.Keys) {
            if ($b -eq $f) { continue }
            if (-not ($b -match '\.(md|markdown)$')) { continue }
            $s = Jaccard $newG (Get-Grams (Get-NameStem $b))
            if ($s -gt $best) { $best = $s; $bestRel = $b }
        }
        if ($best -ge 0.62) {
            $warns.Add(("C5 疑似重复（相似度 {0:N2}）：{1} ～ 存量 {2} ｜ 默认更新存量（DOC-003/008）" -f $best, $f, $bestRel))
        }
    }

    # C6 索引登记
    $leaf = Split-Path $f -Leaf
    $dir = Split-Path $f -Parent
    $candidates = @('docs', 'docs/设计文档', 'docs/设计文档/架构')
    $cur = $dir
    while ($cur -and $cur -ne '.' -and $cur -ne 'docs') {
        $candidates += $cur
        $cur = (Split-Path $cur -Parent)
    }
    $found = $false
    foreach ($d in ($candidates | Select-Object -Unique)) {
        $t = Get-IndexText $d
        if ($t -and $t.Contains($leaf)) { $found = $true; break }
    }
    if (-not $found) {
        $msg = "C6 未登记索引（主题 README / docs/README 未提及）：$f（DOC-006）"
        if ($Strict) { $blocked.Add($msg) } else { $warns.Add($msg) }
    }
}

# ---------- 输出 ----------
Write-Host ''
if ($blocked.Count -eq 0) { Write-Host '[BLOCKED 项] 无' -ForegroundColor Green }
else {
    Write-Host "[BLOCKED 项] $($blocked.Count)" -ForegroundColor Red
    $blocked | ForEach-Object { Write-Host "  X $_" -ForegroundColor Red }
}
if ($warns.Count -eq 0) { Write-Host '[WARN 项] 无' -ForegroundColor Green }
else {
    Write-Host "[WARN 项] $($warns.Count)" -ForegroundColor Yellow
    $warns | ForEach-Object { Write-Host "  ! $_" -ForegroundColor Yellow }
}

$verdict = if ($blocked.Count -gt 0) { 'BLOCKED' } else { 'PASS' }
Write-Host ''
Write-Host "结论：$verdict（新增 $($added.Count) / BLOCKED $($blocked.Count) / WARN $($warns.Count)）"
Write-Host '规则：基线内存量不判违规（DOC-010）；基线刷新仅限存量收口轮次（GOV-012 不得绕过）。'

if ($Blocking -and $blocked.Count -gt 0) { exit 2 }
exit 0
