# Gate Record · CHG-20261009-DOCGOV · PERF / TEST

- **Change**：CHG-20261009-DOCGOV（文档治理 B 档落地）
- **Date**：2026-10-09（结论出具窗口 20:30 前后）
- **Reviewer**：`pc-perf-tester`（自行复跑，未采信口述；本席未写任何文件、未改基线/范围外清单）
- **落盘**：主 Agent（内容原样落盘，未改结论）
- **Scope**：`docs/设计文档/架构` + `docs/README.md` + `.codebuddy/{agents,audit,skills,rules}`

## Gate Results

| Gate | Result | Rule IDs | Evidence | Risk |
|---|---|---|---|---|
| PERF | **N/A** | PERF-001 / PERF-003 | 变更不含运行时/渲染/高频回调路径（交付物=文档 + CLI 门禁脚本）；可复核指标：`doc-guard.ps1` 全量扫描 732 文件 ≈ 0.59 s（一次性 CLI，非热路径） | 无运行时风险面；C5 相似度为 O(新增×基线) 一次性计算，无 Tick 语义 |
| TEST | **PASS** | TEST-001 | 下方 T1–T10（全部由本席复跑，输出原文留存于回话） | ⚠ 并行会话产物干扰（见"操作项"）；沙箱退出码不可观测 |

## TEST 逐项（复跑证据）

| # | 项 | 结论 | 证据摘要 |
|---|---|---|---|
| T1 | 集群审计 | PASS | `audit-subagents.ps1 -Blocking`（20:30:25）：7 agent 全 PASS、`覆盖率 10/10`、`skill 覆盖 9/9`、`注册表双源 OK`、`doc-standard=pc-release-clerk.md` |
| T2 | 路由回归 | PASS | `PASS=22 / FAIL=0`；3 条新增用例实测命中 `pc-release-clerk.md` |
| T3 | 门禁正样本 | PASS（当次） | 首跑 `PASS（新增 2 / BLOCKED 0 / WARN 1）`；WARN 1 = `route-task.tests.ps1` 的瞬态临时文件（并发所致），串行复跑 WARN=0 |
| T4 | 门禁负样本 | PASS 3/3 拦截 | 仓库根 / docs 顶层 / docs 子目录各建无 front-matter `.md` ⇒ 分别命中 C1 / C2 / C3；**清理核实残留 0**（受治理总数复原 735→732） |
| T5 | `-Strict` 行为 | 观察成立 | 同一瞬态文件：`-Blocking` 时 WARN → PASS；加 `-Strict` 后升为 BLOCKED ⇒ WARN→BLOCKED 升级机制实证 |
| T6 | 双副本同步 | PASS（抽验 3/3） | `12-文档与交付物治理规范.md` / `00-规则编号索引.md` / `README.md` SHA256 全等，mtime 一致（20:11:31）。**lint 未复跑**（属写操作，超本席读证边界）——以哈希全等替代 |
| T7 | 脚本解析 | PASS | 4 脚本（route-task / audit-subagents / route-task.tests / doc-guard）parse errors = 0 |
| T8 | 测试自清理 | PASS | `route-task.tests.ps1` try/finally 有效，运行后无残留 |
| T9 | 检索模式 `-Find` | PASS | `-Find 文档治理` → 内容命中 5 条，模式可用 |
| T10 | 新件索引登记 | PASS | 12 分册已被 `docs/README.md`、`架构/README.md`、`00-规则编号索引.md` 收录 |

## Tier 降级声明

- 游戏侧评估 = **Tier C**（无法起游戏进程）；但本变更**无游戏侧验收面**（已核实：21 项交付物零 `Source/`/`Defs/`/`Languages/`/`Textures/`/`About/` 条目），不构成遗留缺口。
- 已执行至环境上限：脚本实跑 + 解析检查 + 回归 22/22 + 门禁正负样本 + 双副本哈希。
- **未执行（明确标注）**：游戏编译、Vanilla 启动、存读档/迁移、DLC/第三方组合、UI 实机关键路径、语言切换——全部"未执行"且对本变更不适用。

## 残余风险

1. **并行会话产物干扰（最高）**：窗口内 ≥3 波外部写入（6 份 ECON 标注 → 瞬态临时文件 → `变更标注_CHG-20261009-ECON-M9-FULL.md`）。**操作项**：主 Agent 将其纳入范围外清单并复跑门禁（预期恢复 PASS）。
2. **沙箱退出码不传播**：任何依赖 exit code 的自动化在此沙箱会得假"成功"；判读必须依赖 stdout 结论行。
3. **C5 阈值漏报**：0.62 Jaccard 仅比对新件标题 vs 基线文件名，对"改名搬运式重复"无感知，且仅 WARN —— 定位为提示，重复治理主责仍在 DOC-003 人工举证。
4. **基线刷新纪律**：日常 `-Rebaseline` = 放行（GOV-012 红线），纯靠执行纪律；本席已核基线运行期未被改动。
5. **双副本 lint 未复跑**：以 SHA256 全等替代；如需"lint 全解析（231 IDs）"级证据，须由有权执行工程外脚本的角色补跑。
6. **并发假阳性窗口**：测试临时文件落在受治理区 `.codebuddy/audit/`，与门禁并发时有 C6/`-Strict` 假阻断窗口（优化建议：改落 `.codebuddy/tmp/**`）。

> 结论出具：`pc-perf-tester`（2026-10-09）；落盘：主 Agent。禁止伪造 PASS（GOV-012）。
