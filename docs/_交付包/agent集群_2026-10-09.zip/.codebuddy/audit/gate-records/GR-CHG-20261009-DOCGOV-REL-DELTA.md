# Gate Record · CHG-20261009-DOCGOV · REL / DELTA

- **Change**：CHG-20261009-DOCGOV（文档治理 B 档落地）
- **Date**：2026-10-09
- **Reviewer**：`pc-release-clerk`（归口 GATE-REL / GATE-DELTA；只读复核，未写文件、未复跑 oracle 脚本，采信其 stdout 结论行 + 独立验证周边一致条件）
- **落盘**：主 Agent（内容原样落盘）
- **说明**：本记录为**补出结论**——主 Record（`GR-20261009-DOCGOV.md`）中 REL/DELTA 原为「未执行（派发失败）」，本记录闭合该缺口。TEST/PERF 见 `GR-CHG-20261009-DOCGOV-PERF-TEST.md`。
- **环境限制（复述）**：本沙箱不传播 PowerShell 退出码 ⇒ 判读一律以 stdout 结论行为准，**不写"退出码已验证"**。

## Gate Results

| Gate | Result | Rule IDs | Evidence | Risk |
|---|---|---|---|---|
| REL | **PASS**（含 1 项操作项） | REL-001（回滚口径参照 REL-007） | 标注 + 主 GR + `doc-journal/2026-10-09/committed/2030-docgov-intake.md` + `docs/README.md`「文档治理基线」段；落点实物；免 EXC 论证；本记录 §回滚；版本面 N/A 依据（21 项零 Source/Defs/Languages/Textures/About） | 低。待办：`sync_from_docs.ps1` 未入 toolchain 册（OP-1）、回滚说明以本记录落盘闭环（OP-2） |
| DELTA | **PASS** | GOV-013 / ANNO-001 / REL-013 | 唯一 oracle 实测：`PASS — 标注覆盖 4 个改动文件，无遗漏/超范围/残留（范围外 2284 不参与判定）`；独立复核：git status「3 M + 1 ??」≡ front matter 4 文件；22 文件残留宽扫仅 3 处规则文本引用；两范围外清单洁净 | 低。残余：范围外判定依赖人工甄别（已以全量 mtime + 样本 diff 加固）、工作区大量未提交积淀 |

> 未执行项：无（本表所属 Gate 全部出具）。

## REL 判定要点

1. **Change Summary 要素完整（PASS）**：等效载体 = 标注 + GR 记录 + journal 申请 + `docs/README.md` 段；REL-002 八要素逐项核对通过。**如实登记 1 处非阻断偏差**：Intake 证据文本为「DOC-001~008」，最终交付为 `DOC-001~010`（随后扩展 009/010）；Intake 属路由证据非承诺，全链其余节点均为 001~010，不构成缺陷。
2. **标注落点（首件实践）合规（PASS）**：落点 = `docs/设计文档/架构/变更标注/`（存量 45 + 首件 1 = 46 文件）；格式符合双段式（front matter 7 字段 + 人工表格 + 范围外 + 证据 + 环境限制），`base: HEAD` 与 oracle 对齐。**观察（非阻断）**：该目录整体未跟踪（`?? 目录级聚合`）。
3. **EXC 判定：不需要 EXC-***（N/A + 理由）：① 定义维——本变更为规范**新增**而非"偏离必须/不得"；② 排查维——逐项排查无规则被跳过或豁免（存量宽限内建于 DOC-010 基线机制）；③ 流程维——属 Minor 级规范变更，四项必须项（新 ID / 索引 / 关联章节 / 迁移说明）已全部完成。与总控判定一致。
4. **回滚说明（PASS，以本记录闭环）**：复核前无任何文件承载回滚说明；本记录 §回滚 给出可执行 10 步。
5. **已知限制登记（基本完整，补登 3 条低风险项）**：已登记 8 条（沙箱退出码 / Tier 降级 / C5 阈值 / 基线纪律 / 并行产物 / lint 未复跑 / 并发假阳性 / 游戏侧未执行）；补登 ⑨ `sync_from_docs.ps1` 未入册 ⑩ 标注目录未跟踪 ⑪ 标注目录计数口径 43/45/46 待统一。
6. **版本/包内一致性：N/A（带理由）**：零包内改动、零运行代码；`About.xml` modVersion 未触碰。

## DELTA 判定要点

1. **双向互含（PASS）**：oracle 实测 PASS；独立复核 git status = ` M docs/README.md`、` M 00-规则编号索引.md`、` M 架构/README.md`、`?? 12-文档与交付物治理规范.md`，与 front matter 3×M + 1×A 完全吻合；docs 子树其余 ` M` 项 mtime ≤ 2026-10-08 01:14（本轮窗口 10-09 19:40–20:35 之外）判为预先存在。
2. **gitignore 区 body 说明合规（PASS）**：`.codebuddy/` 由 `.gitignore:38` 忽略（`git check-ignore` 实测）⇒ 17 项须 body 声明，与标注 §2.1 表一致、非规避；抽查 15+ 件实物与描述**全部对应（无虚列、无缺项）**（含 `doc-baseline.json` 724 文件 / generatedAt=20:09:01）。
3. **Change ID 贯穿（PASS，附 1 处如实登记）**：Summary → Annotation → Gate → journal 全链同 ID；**Intake 证据（`task-doc-gov.txt/.json`，19:59 生成）不含 ID 字符串**（先于 ID 分配），属时序事实、非断链；建议后续 Intake 证据预留 ID 位。Changelog 环节 N/A（见 §3）。
4. **无调试残留（PASS）**：22 文件宽扫命中 3 处，均为规则条款对关键词的**引用文本**（`pc-release-clerk.md:52/119`、`subagent-audit-checklist.md:227`），人工裁定非残留；6 个新建/核心文件独立扫描 `NO_MATCH`；`XXX` 补扫 `NO_XXX`。gate-runner 不扫 `.md`（已知边界），文档侧由人工宽扫兜底。
5. **删除/重命名：无（确认）**：21 项全 A/M；无 D/R；负样本测试文件已清理（受治理总数复原）。
6. **范围外声明合规（PASS + 加固抽查）**：对两清单做 17 关键词扫描 ⇒ **唯一命中为 docguard 清单自身标题注释行**，无实际条目命中（无自我豁免）；`docgov` 清单的 10 个「已跟踪 M 规范文件」经**全量 mtime**（≤10-08 01:14）+ 抽样 diff 验证为预先存在改动，排除正当。

## Changelog 口径建议 —— 维持「不写」，判定可接受

`docs/changelog/` 现有 80+ 条全为 **Mod 版本发布条目**；本变更零玩家可感知面、零版本号变化、零运行代码；`00-规范例外与变更管理 §7` 对 Minor 级规范变更只要求 ID/索引/关联章节/迁移说明四件；用户侧可见性已由 `docs/README.md`「文档治理基线」段承担。**可选**：下次 Mod 版本发布时在 `Changed` 段顺带一句（非义务）。

## 残余风险

| # | 风险 | 依据 |
|---|---|---|
| R-1 | 注册表四处同步 | 可核三处在位（双源机检 + checklist 注册表 + skill 侧挂载点行 9/9）；后两项**无机检**，新增 skill 时最易失同步 |
| R-2 | 规范双副本 + 同步工具未入册 | 双副本 hash/lint 全绿；但 `sync_from_docs.ps1` 在登记册**零登记**（本轮还改过它）⇒ OP-1 |
| R-3 | 基线刷新纪律 | 实核基线 mtime = generatedAt = 20:09:01，运行期未被二次刷新 ✓；后续刷新须用户确认 |
| R-4 | 并行写入者 | 已声明 7+ 条 ECON 并行产物；建议下一轮存量收口统一清算，勿在并行期做 DELTA 终判承诺 |
| R-5 | **git 可见性盲区（新）** | 17 项 `.codebuddy/**` 交付物 + 标注首件（+45 存量标注）未跟踪；`git clean -x` 类操作会造成不可逆丢失；范围外机制的工作前提（人工甄别）将长期面对 2284 项量级积淀 ⇒ 收口轮建议评估纳入 git 或独立备份 |
| R-6 | 文档侧残留扫描的人工性 | gate-runner 不扫 `.md`，属已知机制边界 |
| R-7 | 沙箱退出码不传播 | 判读依赖 stdout 结论行 |

## 回滚步骤（可执行 10 步）

**前提**：4 个 git 可见 docs 文件修改**未提交** ⇒ HEAD 即回滚基线；`.codebuddy/**` 17 项无 git 追溯 ⇒ 手工反向编辑；工程外 C 盘 skill 侧须在工程外执行。**触发条件**：用户裁决撤销 / 门禁误报不可控 / 双副本失控漂移。不影响 Save、无兼容开关（REL-007 元素 N/A）。

1. **快照保全**：21 项交付物 + `git status`/`git diff` 输出打包至 `.codebuddy/tmp/`。
2. **摘审计（先摘检查、后删件，避免审计阻断）**：`route-task.ps1` 移除 `doc-standard`；`audit-subagents.ps1` 移除注册表项 + `$knownSkills` + `$baseLiterals`；`route-task.tests.ps1` 删 3 用例；`subagent-audit-checklist.md` 删四处增量。
3. **拆门禁与设施**：删 `doc-write-gate.md`、`doc-guard.ps1`、`doc-baseline.json`、`skills/doc-standard/`（整目录）；`toolchain-registry.md` 移除 doc-guard / sync 登记。
4. **回退 7 agents**：orchestrator（SKILLS / 文档影响项 / 工作流第 10 步）→ release-clerk（触发词 / SKILLS / 横切节 / 铁律 / 越界禁令）→ 其余 5 agent（越界禁令行）。
5. **docs 侧回退**：`git restore --source=HEAD -- docs/README.md "docs/设计文档/架构/00-规则编号索引.md" "docs/设计文档/架构/README.md"`；`Remove-Item "docs/设计文档/架构/12-文档与交付物治理规范.md"`（若已 commit 则 `git revert`）。
6. **首件标注处置**：推荐**保留留档 + 加「本轮已回滚」注记**（证据链不断）；去留均须登记。
7. **工程外同步回滚（C 盘）**：还原 `references/` 快照（或反向删除 12 分册副本）；`sync_from_docs.ps1` 移除 `DOC` lint 前缀；复跑 sync 验证 Hash 全对。
8. **复验**：`git status -- docs` 仅剩本轮前积淀；全仓 grep `doc-standard` 仅剩历史记录；`audit-subagents.ps1 -Blocking` 与 `route-task.tests.ps1` 呈「未接线」且无悬空引用。
9. **留痕（GOV-012）**：在 `GR-20261009-DOCGOV.md` 追加「回滚执行」条目；`gate-records`、`doc-journal`、`tmp` 证据不静默删除。
10. **基线处置**：基线随步骤 3 删除，**无独立残留**；仅删门禁而留基线 = 无效状态，禁止；重建须新轮用户确认后重新冻结。

## 操作项（主 Agent 处置）

| # | 项 | 状态 |
|---|---|---|
| OP-1 | 登记册补登记 `sync_from_docs.ps1`（或写进 §G「不登记清单」并给理由） | 本轮已处置 |
| OP-2 | 落盘本记录 + 更新主 GR 的 REL/DELTA「未执行」栏 | 本轮已处置 |
| OP-3 | 统一标注目录计数口径（43/45/46） | 可选，并入存量收口轮 |
| OP-4 | 清理 `.codebuddy/tmp/_tmp_docgov_verify_exclude.txt`（自注"跑完即删"） | 本轮已处置 |
| OP-5 | 独立 Change Summary 单页 | 非阻断，不做 |

> 结论出具：`pc-release-clerk`（2026-10-09）；落盘：主 Agent。禁止伪造 PASS（GOV-012）。
