<#
.SYNOPSIS
  确定性路由：任务描述 / 被调用的 skill → 应调用的子 agent 集合（T1–T4 + S1 skill 触发）。
.DESCRIPTION
  数据源 = .codebuddy/agents/*.md 的 ROLE / OWNED_GATES / TRIGGER_KEYWORDS / NO_TRIGGER / SKILLS
  —— 与 audit-subagents.ps1 共用同一套机器契约（单一真相源，不另维护路由表）。

  路由维度（可单用，也可叠加）：
    ① 任务文本（T1–T4）：命中 TRIGGER_KEYWORDS ⇒ 候选；只命中 NO_TRIGGER ⇒ 拒收
    ② skill 触发（S1）：`-Skill <名>` 或**从任务文本自动识别已登记 skill 名** ⇒ 该 skill 声明的 agent 进入候选
  两者叠加时为**两阶段路由**：skill 先收窄域，触发词再精确选择；
  若交集为空但任务侧有候选 ⇒ **回落**到任务匹配并在报告中显式标注（不静默改写结果）。

  优先级裁决（T2 单选）：规范层 P0>P1>P2>P3>P4
    ARCH=P1 · COMP/DATA/SAVE=P2 · UI/LOC=P3 · PERF/TEST/REL/DELTA=P4 · 总控不参与竞争
  无任何命中 ⇒ unrouted（-Blocking 时退出码 3，拒绝静默放行）

  匹配方式：大小写不敏感的**子串匹配**（适配中文短语，无词边界）。
  局限（输出中如实声明）：
    · 硬触发（四个 =Yes / Release / 新增用户可见文本 / 改动持久化字段）无法由文本匹配判定，
      须由 pc-orchestrator 在 AI-001 入口判定；
    · 同义改述若不在触发词表内则不命中 ⇒ 补触发词后重跑审计。
.PARAMETER Task
  任务描述文本（与 -TaskFile / -Skill 至少给一个）
.PARAMETER TaskFile
  从 UTF-8 文件读取任务描述（规避 CJK 参数跨进程编码问题）
.PARAMETER Skill
  被调用的 skill 名（须在注册表内）；不传时自动从任务文本识别 skill 名
.PARAMETER JsonOut
  把结果写成 JSON 文件（UTF-8，供回归测试消费）
.PARAMETER Json
  把结果打到 stdout（JSON）
.PARAMETER Blocking
  unrouted 时退出码 3
.EXAMPLE
  pwsh .codebuddy/audit/route-task.ps1 -Task "改 Save schema 加持久化字段并写 Migration"
  pwsh .codebuddy/audit/route-task.ps1 -Skill summarize
  pwsh .codebuddy/audit/route-task.ps1 -Skill change-report -Task "本次跨模块重构的改动清单"
#>
param(
    [string]$Task,
    [string]$TaskFile,
    [string]$Skill,
    [string]$AgentsDir,
    [string]$JsonOut,
    [switch]$Json,
    [switch]$Blocking
)

$ErrorActionPreference = 'Stop'

if ($TaskFile) {
    if (-not (Test-Path -LiteralPath $TaskFile)) { throw "任务文件不存在: $TaskFile" }
    $Task = Get-Content -LiteralPath $TaskFile -Raw -Encoding UTF8
}
$hasTask = -not [string]::IsNullOrWhiteSpace($Task)
if (-not $hasTask -and [string]::IsNullOrWhiteSpace($Skill)) { throw '必须提供 -Task / -TaskFile / -Skill 至少一个' }

if (-not $AgentsDir) {
    $projRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    $AgentsDir = Join-Path $projRoot '.codebuddy/agents'
}
if (-not (Test-Path -LiteralPath $AgentsDir)) { throw "agents 目录不存在: $AgentsDir" }
$AgentsDir = (Resolve-Path -LiteralPath $AgentsDir).Path

$gateTier = @{ 'ARCH' = 1; 'COMP' = 2; 'DATA' = 2; 'SAVE' = 2; 'UI' = 3; 'LOC' = 3; 'PERF' = 4; 'TEST' = 4; 'REL' = 4; 'DELTA' = 4 }
$tierName = @{ 1 = 'P1 治理架构'; 2 = 'P2 数据/扩展/兼容'; 3 = 'P3 表现'; 4 = 'P4 工程质量'; 5 = 'ORCHESTRATOR 总控' }

# 已登记 skill 注册表 —— 必须与 audit-subagents.ps1 保持一致（audit 侧含双源交叉校验）
$knownSkills = @('RimWorld工程架构规范', 'RimWorld模组开发知识库', 'RimWorld组件绘制', 'RimWorld程序集API静态核实', 'summarize', 'change-report', 'ai-bug-engineering', 'memory-standard', 'doc-standard')

function Get-ContractValue {
    param([string]$Text, [string]$Key)
    $m = [regex]::Match($Text, "(?m)^\s*$Key\s*:\s*(.+?)\s*$")
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    return $null
}

function Parse-CsvList {
    param([string]$Raw)
    if ([string]::IsNullOrWhiteSpace($Raw)) { return @() }
    return @($Raw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

# ---------- 0. 确定 skill 过滤集 ----------
$taskLower = if ($hasTask) { $Task.ToLowerInvariant() } else { '' }
$skillFilter = @()
$skillSource = '无（不按 skill 过滤）'
if (-not [string]::IsNullOrWhiteSpace($Skill)) {
    if (-not $knownSkills.Contains($Skill)) { throw "未登记 skill：$Skill（注册表：$($knownSkills -join ', ')）" }
    $skillFilter = @($Skill)
    $skillSource = 'CLI -Skill'
}
elseif ($hasTask) {
    $detected = @($knownSkills | Where-Object { $taskLower.Contains($_.ToLowerInvariant()) })
    if ($detected.Count -gt 0) { $skillFilter = $detected; $skillSource = '任务文本自动识别' }
}

# ---------- 1. 逐 agent 匹配 ----------
$matched = [System.Collections.Generic.List[object]]::new()
$filteredOut = [System.Collections.Generic.List[object]]::new()
$rejected = [System.Collections.Generic.List[object]]::new()

foreach ($f in @(Get-ChildItem -LiteralPath $AgentsDir -Filter '*.md' -File | Sort-Object Name)) {
    $text = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8
    $role = Get-ContractValue -Text $text -Key 'ROLE'
    $owned = Parse-CsvList (Get-ContractValue -Text $text -Key 'OWNED_GATES')
    $kw = Parse-CsvList (Get-ContractValue -Text $text -Key 'TRIGGER_KEYWORDS')
    $neg = Parse-CsvList (Get-ContractValue -Text $text -Key 'NO_TRIGGER')
    $skillsDeclared = Parse-CsvList (Get-ContractValue -Text $text -Key 'SKILLS')

    $tier = 9
    foreach ($g in $owned) { if ($gateTier.ContainsKey($g) -and $gateTier[$g] -lt $tier) { $tier = $gateTier[$g] } }
    if ($role -ne 'GATE-AGENT') { $tier = 5 }

    $skillPass = ($skillFilter.Count -eq 0) -or (@($skillFilter | Where-Object { $skillsDeclared -contains $_ }).Count -gt 0)
    $skillHits = @($skillFilter | Where-Object { $skillsDeclared -contains $_ })

    $row = [pscustomobject]@{
        File       = $f.Name
        Role       = $role
        Gates      = if ($owned.Count -gt 0) { $owned -join ',' } else { 'NONE' }
        Tier       = $tier
        TierName   = $tierName[$tier]
        Hits       = @()
        SkillHits  = $skillHits
        DeniedHits = @()
    }

    if (-not $hasTask) {
        # skill 驱动：只看 skill 声明
        if ($skillFilter.Count -gt 0 -and $skillPass) { $matched.Add($row) }
        continue
    }

    $hits = @($kw | Where-Object { $taskLower.Contains($_.ToLowerInvariant()) })
    $negHits = @($neg | Where-Object { $taskLower.Contains($_.ToLowerInvariant()) })
    $row.Hits = $hits
    $row.DeniedHits = $negHits

    if ($hits.Count -gt 0) {
        if ($skillPass) { $matched.Add($row) } else { $filteredOut.Add($row) }
    }
    elseif ($negHits.Count -gt 0) {
        $rejected.Add([pscustomobject]@{ File = $f.Name; Hits = $negHits })
    }
}

# ---------- 2. 回落（skill 域内无候选，但任务侧有候选） ----------
$fallbackUsed = $false
if ($hasTask -and $skillFilter.Count -gt 0 -and $matched.Count -eq 0 -and $filteredOut.Count -gt 0) {
    $fallbackUsed = $true
    foreach ($x in $filteredOut) { $matched.Add($x) }
    $filteredOut.Clear()
}

$ordered = @($matched | Sort-Object Tier, File)
$parallel = @($ordered | ForEach-Object { $_.File })
$single = if ($ordered.Count -gt 0) { $ordered[0].File } else { $null }
$unrouted = ($ordered.Count -eq 0)

# ---------- 3. 报告 ----------
$summary = if ($hasTask) { ($Task -replace '\s+', ' ').Trim() } else { '<无任务文本 · 纯 skill 驱动>' }
if ($summary.Length -gt 100) { $summary = $summary.Substring(0, 100) + '…' }

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add('=== 确定性路由（T1–T4 + S1 skill 触发） ===')
$lines.Add("输入源: $(if ($TaskFile) { $TaskFile } elseif ($hasTask) { '<-Task 文本>' } else { '<-Skill>' })")
$lines.Add("任务摘要: $summary")
$lines.Add("skill 过滤: $(if ($skillFilter.Count -gt 0) { ($skillFilter -join ', ') } else { '<无>' })   来源: $skillSource")
$lines.Add("命中 agent: $($ordered.Count)   被 skill 过滤: $($filteredOut.Count)   拒收 agent: $($rejected.Count)")
$lines.Add('')
$lines.Add('命中:')
if ($ordered.Count -eq 0) { $lines.Add('  （无）') }
foreach ($m in $ordered) {
    $lines.Add("  [$($m.TierName)] $($m.File)")
    $ev = @()
    if ($m.Hits.Count -gt 0) { $ev += "触发词: $($m.Hits -join ' / ')" }
    if ($m.SkillHits.Count -gt 0) { $ev += "skill: $($m.SkillHits -join ' / ')" }
    $lines.Add("      Gate=$($m.Gates)   $(if ($ev.Count -gt 0) { $ev -join '   ' } else { 'skill 驱动' })")
    if ($m.DeniedHits.Count -gt 0) { $lines.Add("      ⚠ 同时命中不触发词（TRIGGER 优先）: $($m.DeniedHits -join ' / ')") }
}
if ($filteredOut.Count -gt 0) {
    $lines.Add('')
    $lines.Add('被 skill 过滤（任务命中但不在该 skill 域内）:')
    foreach ($r in $filteredOut) { $lines.Add("  $($r.File)   触发词: $($r.Hits -join ' / ')") }
}
if ($rejected.Count -gt 0) {
    $lines.Add('')
    $lines.Add('拒收（T4：只命中不触发词，不得调用）:')
    foreach ($r in $rejected) { $lines.Add("  $($r.File)   命中不触发词: $($r.Hits -join ' / ')") }
}
$lines.Add('')
if ($unrouted) {
    $lines.Add('决策: UNROUTED —— 无任何 agent 命中。')
    $lines.Add('  建议: 命中 pc-orchestrator（新功能/需求变更/多模块改动/端到端交付）走总控；或补触发词后重跑审计。')
}
else {
    $lines.Add("决策: 并行调用（T2）⇒ $($parallel -join ', ')")
    if ($ordered.Count -gt 1) { $lines.Add("      只能选一个时的优先级裁决 ⇒ $single （$($ordered[0].TierName)）") }
}
if ($fallbackUsed) {
    $lines.Add('')
    $lines.Add('⚠ 回落已发生: skill 域内无候选 ⇒ 结果来自任务匹配（非 skill 域）。')
}
$lines.Add('')
$lines.Add('局限（如实声明）: 硬触发（四个 =Yes / Release / 新增用户可见文本 / 改动持久化字段）')
$lines.Add('                无法由文本匹配判定，须由 pc-orchestrator 在 AI-001 入口判定；')
$lines.Add('                同义改述若不在触发词表内则不命中。')

$reportText = ($lines -join [Environment]::NewLine)

if ($Json -or $JsonOut) {
    $payload = [pscustomobject]@{
        task         = $Task
        skillFilter  = $skillFilter
        skillSource  = $skillSource
        fallbackUsed = $fallbackUsed
        matched      = @($ordered | ForEach-Object { [pscustomobject]@{ File = $_.File; Role = $_.Role; Gates = $_.Gates; Tier = $_.Tier; Hits = $_.Hits; SkillHits = $_.SkillHits } })
        filteredOut  = @($filteredOut | ForEach-Object { [pscustomobject]@{ File = $_.File; Hits = $_.Hits } })
        rejected     = @($rejected | ForEach-Object { [pscustomobject]@{ File = $_.File; Hits = $_.Hits } })
        decision     = [pscustomobject]@{ unrouted = $unrouted; parallel = $parallel; single = $single }
    }
    $jsonText = $payload | ConvertTo-Json -Depth 6
    if ($JsonOut) {
        $outDir = Split-Path -Parent $JsonOut
        if ($outDir -and -not (Test-Path -LiteralPath $outDir)) { $null = New-Item -ItemType Directory -Path $outDir -Force }
        Set-Content -LiteralPath $JsonOut -Value $jsonText -Encoding UTF8
    }
    if ($Json) { Write-Output $jsonText } else { Write-Output $reportText }
}
else {
    Write-Output $reportText
}

if ($Blocking -and $unrouted) { exit 3 }
exit 0
