# 路由回归测试：每条用例 = 任务描述 / skill → 必须命中的 agent（Expect 内每一项都必须出现）
# 用法：pwsh -NoProfile -File .codebuddy\audit\route-task.tests.ps1
# 失败即 exit 2 —— 说明触发词表或 SKILLS 契约被改坏（漏路由），改完必须重跑 audit-subagents.ps1。
$cases = @(
    # ---- 任务文本路由（T1–T4）----
    @{ Name = 'T1/Save'; Task = '改 Save schema，新增持久化字段并写 Migration'; Expect = @('pc-data-steward.md') }
    @{ Name = 'T1/存档'; Task = '改存档迁移逻辑，保证旧档加载不失败'; Expect = @('pc-data-steward.md') }
    @{ Name = 'T1/UI'; Task = '把 HTML 预览落地成游戏内 UI，并补中文本地化 Key'; Expect = @('pc-ui-loc-guard.md') }
    @{ Name = 'T1/兼容'; Task = '用 Harmony 补丁登记接入第三方 Mod，并处理缺失时的降级策略'; Expect = @('pc-compat-auditor.md') }
    @{ Name = 'T1/测试'; Task = '编译验证并跑单元测试，给出性能证据'; Expect = @('pc-perf-tester.md') }
    @{ Name = 'T1/热路径'; Task = '存读档时 UI 重绘卡顿，需要排查热路径扫描'; Expect = @('pc-perf-tester.md') }
    @{ Name = 'T1/发布'; Task = '准备发版：更新 Changelog 并生成变更标注'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'T1/架构'; Task = '重构分层归属，消除循环依赖并评估静态可变状态'; Expect = @('pc-arch-gatekeeper.md') }
    @{ Name = 'T1/总控'; Task = '新增功能，涉及多模块改动，需要端到端交付'; Expect = @('pc-orchestrator.md') }
    @{ Name = 'T1/强制触发词'; Task = '启用标准化agent集群'; Expect = @('pc-orchestrator.md') }
    @{ Name = 'T1/记忆'; Task = '把这个约定写记忆：先审核后写入'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'T1/文档治理'; Task = '新建文档：记录经济系统模块设计方案，并登记到 docs 索引'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'T1/文档落点'; Task = '把变更标注归档到 docs 设计文档架构变更标注目录'; Expect = @('pc-release-clerk.md') }

    # ---- skill 触发（S1）----
    @{ Name = 'S1/纯 skill'; Skill = 'RimWorld工程架构规范'; Expect = @('pc-arch-gatekeeper.md', 'pc-ui-loc-guard.md', 'pc-orchestrator.md') }
    @{ Name = 'S1/summarize'; Skill = 'summarize'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'S1/change-report'; Skill = 'change-report'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'S1/ai-bug'; Skill = 'ai-bug-engineering'; Expect = @('pc-perf-tester.md') }
    @{ Name = 'S1/memory-standard'; Skill = 'memory-standard'; Expect = @('pc-release-clerk.md') }
    @{ Name = 'S1/doc-standard'; Skill = 'doc-standard'; Expect = @('pc-release-clerk.md') }

    # ---- skill × 任务 两阶段路由 ----
    @{ Name = 'S1+Task/文本识别'; Task = '调用 RimWorld模组开发知识库 查 Scribe API，然后改 Save schema'; Expect = @('pc-data-steward.md') }
    @{ Name = 'S1+Task/交集'; Skill = 'RimWorld工程架构规范'; Task = '重构分层归属，消除循环依赖'; Expect = @('pc-arch-gatekeeper.md') }
    @{ Name = 'S1+Task/回落'; Skill = 'summarize'; Task = '改 Save schema 加持久化字段'; Expect = @('pc-data-steward.md') }
)

$router = Join-Path $PSScriptRoot 'route-task.ps1'
# 临时文件落 .codebuddy/tmp（doc-guard 排除区）：避免与 doc-guard 并发时产生 C6 假阳性
# （2026-10-09 实测：落 .codebuddy/audit/ 时并发会 WARN，-Strict 下假 BLOCKED）
$tmpDir = Join-Path (Split-Path $PSScriptRoot -Parent) 'tmp'
if (-not (Test-Path -LiteralPath $tmpDir)) { New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null }
$tmpTask = Join-Path $tmpDir '_tmp_route_task.txt'
$tmpJson = Join-Path $tmpDir '_tmp_route_out.json'
$pass = 0
$fail = 0

try {
    foreach ($c in $cases) {
        $argv = @('-NoProfile', '-File', $router)
        if ($c.ContainsKey('Skill') -and $c.Skill) { $argv += @('-Skill', $c.Skill) }
        if ($c.Task) {
            Set-Content -LiteralPath $tmpTask -Value $c.Task -Encoding UTF8
            $argv += @('-TaskFile', $tmpTask)
        }
        $argv += @('-JsonOut', $tmpJson)

        & pwsh @argv | Out-Null

        $obj = Get-Content -LiteralPath $tmpJson -Raw -Encoding UTF8 | ConvertFrom-Json
        $got = @()
        if ($obj.matched) { $got = @($obj.matched | ForEach-Object { $_.File }) }

        $missing = @($c.Expect | Where-Object { $got -notcontains $_ })
        if ($missing.Count -eq 0) {
            $pass++
            Write-Output "[PASS] $($c.Name)"
            Write-Output "        -> $($got -join ', ')"
        }
        else {
            $fail++
            Write-Output "[FAIL] $($c.Name)"
            Write-Output "        输入: skill=$($c.Skill)  task=$($c.Task)"
            Write-Output "        期望含: $($c.Expect -join ', ')"
            Write-Output "        实际:   $($got -join ', ')"
        }
    }
}
finally {
    Remove-Item -LiteralPath $tmpTask, $tmpJson -Force -ErrorAction SilentlyContinue
}

Write-Output ''
Write-Output "路由回归: PASS=$pass / FAIL=$fail"
if ($fail -gt 0) { exit 2 }
exit 0
