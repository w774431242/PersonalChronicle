# 子 agent 合规审计清单（逐 agent 勾选）

**规则依据**：`GOV-012`（不得绕过 Gate / 例外 / 确认）· `AI-001`（任务入口）· `AI-009`（Gate 协议）· `AI-011`（违规分级）· `GOV-013` / `ANNO-001` / `REL-013`（变更标注）· `GATE-DELTA`
**规范源**：`C:\Users\Administrator\.codebuddy\skills\RimWorld工程架构规范`
**自动校验**：`pwsh .codebuddy/audit/audit-subagents.ps1 -Blocking`（BLOCKED 退出码 2）
**结果四态**：`PASS` / `PASS WITH EXCEPTION` / `BLOCKED` / `N/A`（N/A 必须写明理由）
**总则**：任一 `P0/P1` 失败阻止派发；没有可执行环境时诚实标记"未执行"，**不得伪造 PASS**。

---

## 0. 集群级检查（每轮全量审计必做）

```text
[ ] 7 个 agent 定义文件齐备（1 总控 + 6 Gate agent）
[ ] 10 道 Gate 全覆盖：ARCH DATA SAVE LOC UI COMP TEST PERF REL DELTA
[ ] 无 Gate 重复归属（同一 Gate 不得由两个 agent 负责）
[ ] 每个 agent 的 OWNED_GATES 与预期映射完全一致（无越界、无漏派）
[ ] 每个 agent 的 FORBIDDEN_GATES == 全部 Gate − OWNED_GATES（总控为 NONE）
[ ] 每个 agent 含 ROLE / OWNED_GATES / FORBIDDEN_GATES 三行机器契约
[ ] 每个 agent 含 AI-001 入口绑定、GOV-012、Tier 降级、Evidence、references/ 分册引用
[ ] 每个 agent 声明落盘路径 .codebuddy/audit/gate-records/
[ ] 每个 agent 含 TRIGGER_KEYWORDS（≥3 项）与 NO_TRIGGER（≥1 项）两行机器契约
[ ] 触发词全局唯一（无两个 agent 抢同一触发词 ⇒ 自动调用路由无二义）
[ ] 同一 agent 内 触发词 ∩ 不触发 == 空
[ ] 每个 agent 含 SKILLS 行（≥1 项），且每个 skill 名 ∈ 脚本注册表
[ ] 注册表里每个 skill 至少被一个 GATE-AGENT 声明（总控全声明不算数）
[ ] 每个 agent 引用本机工具链登记册（机器校验：`$baseLiterals` 含 `toolchain-registry.md`）
[ ] 每个 agent 引用文档产出规范（机器校验：`$baseLiterals` 含 `doc-standard`）
[ ] 文档域治理件齐备：`.codebuddy/skills/doc-standard/` + `.codebuddy/rules/doc-write-gate.md` + `.codebuddy/audit/doc-guard.ps1` + `.codebuddy/audit/doc-baseline.json`
[ ] 无未登记 agent 文件
```

预期映射（唯一裁决源）：

| 文件 | 角色 | 归属 Gate |
|---|---|---|
| `pc-orchestrator.md` | ORCHESTRATOR | NONE（不下场跑 Gate） |
| `pc-arch-gatekeeper.md` | GATE-AGENT | `ARCH` |
| `pc-data-steward.md` | GATE-AGENT | `DATA`,`SAVE` |
| `pc-ui-loc-guard.md` | GATE-AGENT | `UI`,`LOC` |
| `pc-compat-auditor.md` | GATE-AGENT | `COMP` |
| `pc-perf-tester.md` | GATE-AGENT | `PERF`,`TEST` |
| `pc-release-clerk.md` | GATE-AGENT | `REL`,`DELTA` |

### 0.1 触发规则（自动调用契约）

`mode: agentic` ⇒ 是否调用由主 Agent 语义匹配 `description` 判断，**不是规则引擎**（无关键词表驱动的确定性路由、无事件钩子、无路径 glob）。以下四条为可审计的确定性约束：

| 规则 | 内容 |
|---|---|
| **T1 命中即调** | 需求命中某 agent 的 `TRIGGER_KEYWORDS` 任一 ⇒ 唤起该 agent |
| **T2 多命中并行** | 命中多个 ⇒ 各自并行调用（不同 Gate 本就并行）；**只能选一个**时按规范优先级 `P0>P1>P2>P3>P4` 裁决：`ARCH` > `COMP/DATA/SAVE` > `UI/LOC` > `PERF/TEST/REL/DELTA`；无法裁决 ⇒ 提交 Architecture Review |
| **T3 硬触发优先** | 硬触发（四个 `=Yes` 标记 / 任何 Release 交付 / 新增用户可见文本 / 改动持久化字段 / 需出 TEST·PERF 结论）⇒ 无需语义判断，必唤起 |
| **T4 不触发拒收** | 需求只命中某 agent 的 `NO_TRIGGER` ⇒ 不得调用它，转交对应 agent（越界即 `BLOCKED`） |

各 agent 触发词（脚本强制：≥3 项、全局唯一、与自身 `NO_TRIGGER` 不冲突）：

| Agent | 触发词 |
|---|---|
| `pc-orchestrator` | 新功能 · 新增功能 · 需求变更 · 多模块改动 · 端到端交付 · 集群自审 · 派发裁决 · 重构 · 启用标准化agent集群 |
| `pc-arch-gatekeeper` | 分层归属 · 依赖方向 · 循环依赖 · 跨模块依赖 · 架构审查 · 静态可变状态 · 继承与组合选型 · 大文件切片 |
| `pc-data-steward` | Def 静态配置 · DefModExtension · Comp 数据边界 · Read Model 快照 · Provider 契约 · Scribe 序列化 · 持久化字段 · Save schema · Migration 迁移 · 存档迁移 · 旧档加载 |
| `pc-ui-loc-guard` | UI 窗口组件 · Theme Token · 颜色魔法值 · 本地化 · 本地化 Key · Keyed 覆盖 · fallback 文案 · 贴图资产 · 预览落地 |
| `pc-compat-auditor` | 第三方 Mod · 第三方 Mod 接入 · DLC 接入 · 软依赖声明 · 硬依赖声明 · PatchOperations · Harmony 补丁登记 · 加载顺序 · 降级策略 |
| `pc-perf-tester` | 编译验证 · 单元测试 · 性能证据 · 回归测试 · 热路径扫描 · 刷新门控 · 基准指标 |
| `pc-release-clerk` | 发版 · Changelog · Changelog 更新 · 变更标注 · 变更标注归档 · 交付终检 · 版本号一致性 · 回滚说明 · 记忆标准化 · 写记忆 · 记住这个 · 保存偏好 · 记一下 · 文档治理 · 新建文档 · 写文档 · 更新文档 · 文档落点 · 文档索引 |

### 0.2 路由实现（可执行）

触发词表 = 路由表（**单一真相源**，不另维护）；`.codebuddy/audit/route-task.ps1` 直接读 agent 文件的机器契约做**确定性**匹配。

```powershell
# 单次路由：命中证据 + 覆盖率 + 优先级裁决
pwsh .codebuddy/audit/route-task.ps1 -Task "改 Save schema 加持久化字段并写 Migration，然后发版"
# 文件输入 / JSON 落盘 / unrouted 时 exit 3
pwsh .codebuddy/audit/route-task.ps1 -TaskFile task.txt -JsonOut route.json -Blocking
# 路由回归测试（9 条真实任务）；FAIL ⇒ exit 2
pwsh .codebuddy/audit/route-task.tests.ps1
```

算法：`T1` 子串命中触发词 → 候选（命中词即证据）· `T4` 只命中不触发词 → 拒收 · `T2` 多命中并行 + 单选优先级裁决（`P0>P1>P2>P3>P4`）· 全不命中 → `UNROUTED`（`-Blocking` 时 exit 3，拒绝静默放行）。

⚠️ **已知局限（脚本输出中如实声明，不掩盖）**：
- **硬触发无法由文本匹配判定**（四个 `=Yes` / Release / 新增用户可见文本 / 改动持久化字段）⇒ 须由 `pc-orchestrator` 在 `AI-001` 入口判定；
- **同义改述不在触发词表内则不命中** ⇒ 漏路由时**补触发词**，然后**必须重跑** `audit-subagents.ps1`（校验 ≥3 项 / 全局唯一 / 与自身不触发不冲突）+ `route-task.tests.ps1`（防改坏）。

⚠️ **残余风险（必须承认）**：`description` 与触发词本身仍只是**语义锚点**。`route-task.ps1` 提供的是**离线可复现的确定性路由**，主 Agent 的在线自动调用仍可能不遵循它 ⇒ 要求 100% 确定时，关键节点须走 `manual` 模式显式点名调用，或由 `pc-orchestrator` 统一分发。

### 0.3 skill → agent 触发（S1）

**已登记 skill 注册表**（唯一白名单；硬编码在 `audit-subagents.ps1` 与 `route-task.ps1` 内，**两处必须一致**）：

| skill | 唤起的 Gate agent | 语义 |
|---|---|---|
| `RimWorld工程架构规范` | 全部 6 个 | 总纲（治理/架构/数据/兼容/表现/发布/AI 协议） |
| `RimWorld模组开发知识库` | `pc-data-steward` · `pc-compat-auditor` · `pc-perf-tester` | API 事实（Scribe / Harmony / 性能 API） |
| `RimWorld组件绘制` | `pc-ui-loc-guard` | 组件绘制 / 预览 1:1 落地 → UI/LOC |
| `RimWorld程序集API静态核实` | `pc-arch-gatekeeper` · `pc-compat-auditor` | API 事实取证 → 扩展点 / 兼容判定 |
| `ai-bug-engineering` | `pc-perf-tester` | 缺陷生命周期 → TEST/PERF |
| `summarize` | `pc-release-clerk` | 交付总结 → REL |
| `change-report` | `pc-release-clerk` | diff 级改动凭据 → DELTA |
| `memory-standard` | `pc-release-clerk` | 记忆写入规范（先审核后写入 / 当日归集 / 字段结构化 / 长短期分离）→ 记录与留痕侧（**非独立 Gate**） |
| `doc-standard` | `pc-release-clerk` | 文档与交付物治理（DOC-001~010：更新优先 / 新建审批门 / 落点与索引 / 取代登记 / 双副本同步）→ 文档域（**非独立 Gate**，验收并入 GATE-DELTA + `doc-guard.ps1`） |

各 agent 的 `SKILLS:` 机器契约与 `TRIGGER_KEYWORDS` / `NO_TRIGGER` 同属机器契约族（写在同一个 `text` 围栏内）。总控 `pc-orchestrator` 声明除 2 个专项取证 skill（`RimWorld组件绘制` / `RimWorld程序集API静态核实`）外的全部 6 个（统一分发），但 **skill 覆盖检查只统计 Gate agent**，避免总控"全声明"把覆盖检查架空。

**审计强制项**：① `SKILLS:` 行齐备且非空 ② 每个 skill 名 ∈ 注册表（未登记即 `BLOCKED`）③ 注册表里每个 skill 至少被一个 Gate agent 声明（缺失即 `BLOCKED`）。

**调用方式**：

```powershell
pwsh .codebuddy/audit/route-task.ps1 -Skill summarize                           # 纯 skill 触发
pwsh .codebuddy/audit/route-task.ps1 -Task "调用 RimWorld模组开发知识库 查 API"   # 从文本自动识别 skill
pwsh .codebuddy/audit/route-task.ps1 -Skill change-report -Task "跨模块重构"      # 两阶段路由
```

**两阶段路由**：skill 先收窄域 → 触发词再精确选择；**交集为空但任务侧有候选 ⇒ 回落到任务匹配并在报告中显式标注**（不静默改写结果）。

**skill 侧挂载点**（本 skill 被调用时才知道要建集群）：`RimWorld工程架构规范/SKILL.md`「子 agent 集群触发」节 · `RimWorld模组开发知识库/SKILL.md` · `RimWorld组件绘制/SKILL.md` · `RimWorld程序集API静态核实/SKILL.md` · `ai-bug-engineering/SKILL.md` · `.codebuddy/skills/summarize/SKILL.md` · `.codebuddy/skills/change-report/SKILL.md` · `.codebuddy/skills/memory-standard/SKILL.md` · `.codebuddy/skills/doc-standard/SKILL.md` 各自的「与子 agent 集群联动」节（9 个注册 skill 全覆盖）。

### 0.4 本机工具链事实（登记册）

**单一真相源**：`.codebuddy/audit/toolchain-registry.md`（五分类 A–E：编译与部署链 / 反编译与 API 取证 / 断点调试 / 资源与预览 / 发布与校验 + agent 主用映射 + 已知漂移；每项含位置、用途、调用方式、最后验证日期）。

- **定位边界**：登记册管「工具事实」· 规范 skill 管「规则」· `memory/*.md` 管「历史教训」· `docs/开发参考/工具使用手册.html` 管「人向教程」——四者互链、互不代替。
- **机器强制**：`$baseLiterals` 含 `toolchain-registry.md` ⇒ 7 个 agent 定义必须引用，缺失即 `BLOCKED`；但审计**只校验引用存在、不校验工具存在**（路径属本机环境事实，跨机/重装会失效 ⇒ 依赖工具结论前先按登记册「调用方式」自证，无法自证标"未执行"）。
- **维护纪律**：工具新增 / 迁移 / 卸载 ⇒ **同日**更新登记册 + 刷新「最后验证」列 + 复跑 `audit-subagents.ps1 -Blocking` 与 `route-task.tests.ps1`。

---

## 1. pc-orchestrator（总控 / 裁决）

```text
S1  需求入口
[ ] 先跑 AI-001：目标/非目标·涉及文件·层级·规则ID·第三方影响·ArchReview?·扩展点计划·Gate计划
[ ] 信息不足时采用最小安全假设并标记，未凭方便扩大范围
S2  派发前置
[ ] 派发前跑 audit-subagents.ps1 -Blocking，BLOCKED 时不派发
[ ] 同一 Gate 未同时派给两个 agent
S3  裁决
[ ] 按 AI-011 分级：P0/P1 阻止 Release，未用"能编译"覆盖架构问题
[ ] 需要偏离规范时按 EXC 模板登记（范围/理由/风险/替代/负责人/到期日）
S4  交付
[ ] 汇总 Gate Results 表（AI-012：Implementation Summary + Gate Results + Remaining Risks）
[ ] 跑 gate-runner.ps1 -Blocking 做 GATE-DELTA 终检
[ ] 变更标注已生成，Change ID 贯穿 Intake→Summary→Annotation→Gate→Changelog
[ ] 未亲自跑任何 Gate，未直接编写模块业务代码
```

## 2. pc-arch-gatekeeper（`ARCH`）

```text
S1  [ ] 接收 AI-001 入口子集（涉及文件 + 改动摘要 + 任务层级）
S2  [ ] 标出依赖方向与数据边界，核对 00-规范关系矩阵.md 允许方向
S2  [ ] AI-003 扩展点风险升序，被跳过方案已记录理由
S2  [ ] Harmony/继承/全局状态有必要性说明；四个 =Yes 任一 → 要求 EXC 登记
S5  [ ] GATE-ARCH 清单逐条判（含 ARC-013 大文件治理、切片未改契约）
S9  [ ] 落盘 .codebuddy/audit/gate-records/GR-<ChangeID>-ARCH.md
S10 [ ] 结论带 Evidence（文件:行号），未伪造 PASS，N/A 带理由
越界 [ ] 未对 DATA/SAVE/LOC/UI/COMP/TEST/PERF/REL/DELTA 出结论
```

## 3. pc-data-steward（`DATA` + `SAVE`）

```text
S1  [ ] 接收 AI-001 入口子集（Def/Runtime/Save/Provider 清单）
S3  [ ] 四类数据已分离：Def(静态) / Runtime State / Save Data / UI State，无错位
S5  [ ] GATE-DATA 清单逐条判（缓存可从权威数据重建）
S7  [ ] AI-007 七项已写出：旧→新 schema·默认值·未知值降级·重命名映射·幂等·失败隔离·旧档测试
S7  [ ] 无法证明旧 Save 行为时暂停并报告，未假定"字段自动兼容"
S5  [ ] stableId 一贯性（<defName>:<thingIDNumber>），逻辑键为 defName
S9  [ ] 落盘 .codebuddy/audit/gate-records/GR-<ChangeID>-DATA-SAVE.md
S10 [ ] 结论带 Evidence，未伪造 PASS，未把 UI/翻译/Texture 写进 Save
越界 [ ] 未对 ARCH/LOC/UI/COMP/TEST/PERF/REL/DELTA 出结论
```

## 4. pc-ui-loc-guard（`UI` + `LOC`）

```text
S1  [ ] 接收 AI-001 入口子集（UI/Key/Asset 清单）
S2  [ ] 预览落地任务已走 11-预览落地标准化规范.md（LAND-001~014）
S3  [ ] 颜色走 Theme Token，无散落魔法值；UI State 不持持久状态
S5  [ ] GATE-UI 清单逐条判（五态完整、大列表降级、Empty/Loading/Error）
S6  [ ] AI-006 六项：Key 命名空间·默认语言·fallback·参数一致·长文本·Translation 扫描
S6  [ ] 1.6 带参翻译用 Translate(NamedArgument)，未用 params object[]
S9  [ ] 落盘 .codebuddy/audit/gate-records/GR-<ChangeID>-UI-LOC.md
S10 [ ] 结论带 Evidence，未按显示文本做逻辑判断（GOV-009）
越界 [ ] 未对 ARCH/DATA/SAVE/COMP/TEST/PERF/REL/DELTA 出结论
```

## 5. pc-compat-auditor（`COMP`）

```text
S1  [ ] 接收 AI-001 入口子集（目标 Mod / 依赖类型 / Patch 清单）
S2  [ ] 接入链路 = 检测→能力判断→Adapter→项目 Contract→可选消费（GOV-008）
S5  [ ] GATE-COMP 清单逐条判：Core 不直连目标 Mod、缺失可运行
S5  [ ] 目标 Mod 失败时降级并记录一次结构化诊断（无空 catch、无无界重试）
S5  [ ] Harmony 已登记（GOV-007）且有理由/范围/回滚；未登记即 BLOCKED
S9  [ ] 落盘 .codebuddy/audit/gate-records/GR-<ChangeID>-COMP.md
S10 [ ] "缺失时可运行"无法证明时未 PASS（BLOCKED 或带理由 N/A）
越界 [ ] 未对 ARCH/DATA/SAVE/LOC/UI/TEST/PERF/REL/DELTA 出结论
```

## 6. pc-perf-tester（`PERF` + `TEST`）

```text
S1  [ ] 接收 AI-001 入口子集（编译 / 测试 / 性能验证目标）
S5  [ ] 权威链路编译通过且 0 错 0 警：`_scripts/compile_with_sdk.ps1`（csc 无输出 = 通过）；禁以 `dotnet build` 判工程健康（csproj 显式清单会报假错误）
S5  [ ] GATE-PERF 清单逐条判：热路径无全库扫描/反射/无界分配
S5  [ ] UI 重绘受 CacheRefreshInterval 门控，非每帧重算
S5  [ ] 性能结论可复核（有指标）；给不出即 BLOCKED，未凭直觉 PASS
S9  [ ] 落盘 .codebuddy/audit/gate-records/GR-<ChangeID>-PERF-TEST.md
S10 [ ] Tier 降级如实（有编译+单测=Tier B；仅静态=Tier C；无法起游戏标"未执行"）
越界 [ ] 未对 ARCH/DATA/SAVE/LOC/UI/COMP/REL/DELTA 出结论
```

## 7. pc-release-clerk（`REL` + `DELTA`）

```text
S1  [ ] 接收 AI-001 入口子集（改动清单 + Change ID）
S9  [ ] 变更标注已生成（YAML front matter 段 + 表格段一致）
S9  [ ] 跑 gate-runner.ps1 -Base origin/main -Annotation <标注> -Blocking 通过
S9  [ ] 版本真源一致：About.xml modVersion == 代码侧版本常量
S9  [ ] Changelog 分类准确 + Breaking/Migration/回滚说明 + EXC 在有效期
S10 [ ] Change ID 在 Intake/Summary/Annotation/Gate/Changelog 间可互链
S10 [ ] 删除/重命名项已登记 Deprecated 或 Migration
S10 [ ] 无调试残留（TODO/FIXME/HACK/XXX:/Console.Write/Debug.Log/Debugger.Break）
S11 [ ] 记忆写入走 memory-standard：先出 pending 草稿求用户确认，未确认未落 committed/（严禁先写后报）
S11 [ ] 记忆条目字段完整 / 短期带 until / 落点 .codebuddy/memory-journal/（未混入 gate-records/、未替代 .codebuddy/memory/ 每日日志）
S11 [ ] 文档产出走 doc-standard：新建前已检索存量（DOC-003）+ 先出申请并获用户确认（DOC-004），未确认未落盘（严禁先写后报）
S11 [ ] 落点 / 索引 / 取代合规（DOC-001/006/007）；新增文档 front-matter 六字段齐备；同主题未建并列版本文件（DOC-008）
S11 [ ] 交付跑过 doc-guard.ps1 -Blocking（无 BLOCKED）；规范类改动已跑 sync_from_docs.ps1（EXITCODE=0）（DOC-009/010）
越界 [ ] 未重写业务代码；发现问题只出 BLOCKED 并回退给对应 agent
```

---

## 8. 审计产出（Gate Record）

```markdown
## Gate Record
- Change: AUDIT-AGENTS
- Date: YYYY-MM-DD
- Reviewer: audit-subagents.ps1
- Scope: .codebuddy/agents/

| 文件 | 角色 | 归属 Gate | 结构 | 契约 | 要素 | 结论 |
|---|---|---|---|---|---|---|

| Gate | 归属 Agent | 关联规则 ID |
|---|---|---|
| ARCH | pc-arch-gatekeeper | GOV-001/MATRIX-001/ARC-001/ARC-013 |
| DATA | pc-data-steward | DATA-001/DATA-004/SAVE-001 |
| SAVE | pc-data-steward | SAVE-001/SAVE-004 |
| LOC | pc-ui-loc-guard | LOC-001/LOC-004/COMP-007 |
| UI | pc-ui-loc-guard | UI-001/ASSET-001/PERF-002 |
| COMP | pc-compat-auditor | COMP-001/COMP-004 |
| TEST | pc-perf-tester | TEST-001 |
| PERF | pc-perf-tester | PERF-001/PERF-003 |
| REL | pc-release-clerk | REL-001 |
| DELTA | pc-release-clerk | GOV-013/ANNO-001/REL-013 |
```
