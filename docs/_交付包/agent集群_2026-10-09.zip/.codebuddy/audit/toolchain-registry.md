# 本机工具链登记册（agent 集群共享 · 单一真相源）

> **给 agent**：需要"用工具"时**先查本册**（位置 / 用途 / 调用方式 / 主用 agent / 最后验证），不要凭记忆猜路径。
> **给人**：全量教程（含截图/背景/工作流）在 `docs/开发参考/工具使用手册.html`，两者互链、互不替代。

## 0. 定位与维护纪律

- **SSOT 边界**：本册 = **本机工具事实**（位置 / 调用方式 / 验证日期）+ agent 用法映射；规范 skill 管「规则」；`memory/*.md` 管「历史教训」；HTML 手册管「人向教程」。
- **机器强制**：`audit-subagents.ps1` 的 `$baseLiterals` 含 `toolchain-registry.md` ⇒ 7 个 agent 定义必须引用本册，缺失即 `BLOCKED`（防"agent 不知道有什么工具"）。
- **审计只校验"引用存在"，不校验"工具存在"**：路径属本机环境事实，跨机/重装即可能失效 ⇒ 依赖工具结论时必须先按「调用方式」列自证（无法自证 ⇒ 标"未执行"，GOV-012）。
- **维护纪律**：工具新增 / 迁移 / 卸载 ⇒ **同日**更新本册 + 刷新「最后验证」列 + 复跑 `audit-subagents.ps1 -Blocking` 与 `route-task.tests.ps1`。
- **环境指纹**（2026-10-09）：Windows · RimWorld **1.6.4871 rev590** · 游戏根 `E:\SteamLibrary\steamapps\common\RimWorld` · 工程根 `E:\SteamLibrary\steamapps\common\RimWorld\11\殖民地综合管理系统`

---

## A. 编译与部署链（主用：`pc-perf-tester`）

| 工具 | 位置 | 用途 | 调用方式 | 最后验证 |
|---|---|---|---|---|
| .NET SDK **8.0.424** | `D:\toolbox\dotnet\sdk\8.0.424`（`dotnet` 在 PATH） | Roslyn `csc.dll` 全语法编译 Mod DLL | `pwsh -NoProfile -File _scripts\compile_with_sdk.ps1` | 2026-10-09 |
| 工程 csproj（`net48`） | `Source\PersonalChronicle.csproj` | IDE / 标准 `dotnet build` 路径；`Microsoft.NETFramework.ReferenceAssemblies` 1.0.3 | ⚠ **禁用于判工程健康**（`EnableDefaultCompileItems=false` + 显式清单漏目录 ⇒ 假错误，且不产出可部署 DLL） | 2026-10-09 |
| net472 / net48 引用程序集 | `~\.nuget\packages\microsoft.netframework.referenceassemblies[.net472/.net48]` | 满足官方唯一硬性要求「必须能编译 .NET Framework 4.7.2」 | 由 csproj `PackageReference` 自动引入 | 2026-10-09 |
| 部署脚本 | `_scripts\deploy-to-game.ps1` | 编译产物 → 游戏 `Mods\` 发布区 | `pwsh -NoProfile -File _scripts\deploy-to-game.ps1` | 2026-10-09 |
| 单元测试 | `Tests\PersonalChronicle.Tests.csproj` | 单测（Release） | `dotnet test Tests\PersonalChronicle.Tests.csproj -c Release` | 2026-10-09 |
| 工程专项审计脚本群（30+） | `_scripts\audit_*.ps1` · `_scripts\verify-*.ps1` | Def/Scribe/KeyRef/CJK/健康度等静态审计 | 按名调用（如 `audit-scribe.ps1`、`audit_full_health.ps1`） | 2026-10-09 |

## B. 反编译与 API 取证（主用：`pc-arch-gatekeeper` / `pc-data-steward` / `pc-compat-auditor`）

| 工具 | 位置 | 用途 | 调用方式 | 最后验证 |
|---|---|---|---|---|
| **仓内原版反编译源** | `_research\vanilla\Assembly-CSharp\`（**9227 个 .cs**，gitignore 故 `list_dir` 不显示但存在） | 查原版 API/机制**首选**（免反编译、可 grep） | `search_content` 直接检索；⚠ **别用** `RimWorld\Source`（仅 43 个 .cs，非全源） | 2026-10-09 |
| **dnSpyEx** | `D:\toolbox\辅助工具\dnSpyEx\dnSpy.exe`（另有 `dnSpy.Console.exe`） | GUI 反编译 + 运行时调试附加 | 打开 DLL 浏览；调试见 §C | 2026-10-09 |
| ilspycmd | `C:\Users\Administrator\.dotnet\tools\ilspycmd.exe` | CLI 反编译（可管道 grep 类型/成员） | `ilspycmd <dll>` · `ilspycmd -t <Type> <dll>` | 2026-10-09 |
| **Mono.Cecil 取证工具** | `D:\toolbox\cecil-dump`（`Dumper.csproj` + 输出 txt） | 静态核实成员签名 / 引用点扫描 / 子类枚举（**不需启动游戏、不受反射沙箱拦截**） | 见 `memory/reference_cecil_dumper.md` 用法记录 | 2026-10-09 |
| InspectTypes（工程自建） | `InspectTypes\`（`Program.cs` + csproj） | 批量类型检查 | `dotnet run --project InspectTypes` | 2026-10-09 |

## C. 断点调试（主用：全部 Gate agent 排障时的升级手段）

| 工具 | 位置 | 用途 | 调用方式 | 最后验证 |
|---|---|---|---|---|
| **RimWorld Doorstop 工具包** | `D:\toolbox\辅助工具\RimWorldDoorstop\` | RimWorld 用定制 Mono，普通 .NET 调试器无法附加；Doorstop 注入后开启 Mono 调试服务器 | 已注入游戏根（`winhttp.dll` + `Doorstop.dll` + `doorstop_config.ini`）；`deploy.ps1` / `undeploy.ps1` 可逆；端口 `127.0.0.1:56000` | 2026-10-09（**运行时附加未实测**） |
| 调试前端 | `D:\toolbox\辅助工具\dnSpyEx\dnSpy.exe` | 附加断点/单步/看变量 | `Debug > Start Debugging > Debug engine: Unity > 127.0.0.1:56000` | 2026-10-09 |

> 前提：① 编译产物带 `.pdb`（裸 csc 链路需加 `/debug:portable`，默认不产 ⇒ 断点不命中）；② 从游戏根 `RimWorldWin64.exe`（或 Steam）启动，勿用其它工作目录的启动器。完整说明见工具包内 `README.md`。

## D. 资源与预览（主用：`pc-ui-loc-guard`）

| 工具 | 位置 | 用途 | 调用方式 | 最后验证 |
|---|---|---|---|---|
| Python **3.11.9**（Pillow 12.3.0） | `D:\toolbox\python\python.exe` | 贴图批处理 / 生成 / 资产管线脚本 | `python <script.py>`；例：`Tools\medal_master_pipeline.py` | 2026-10-09 |
| Node.js **26.8.1** | `D:\toolbox\node-v26.8.1-win-x64` | chrome-devtools MCP（`npx`）/ JS 工具 | `node` / `npx` | 2026-10-09 |
| VS Code | `%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe` | 文本/XML 编辑（**未装 C#/XML 扩展 ⇒ 非 IDE**） | `code <path>` | 2026-10-09 |
| 预览资产 + DevTools MCP | `docs\UI预览\`（HTML 预览）+ chrome-devtools MCP | UI 1:1 落地：量取/截图/交互验证 | 本地 http 服务 + MCP 截图（见 `docs\开发参考\` 手册 §3.3） | 2026-10-09 |
| RimSort / RimPy | 游戏根 `RimSort-v1.12.0-Windows_x86_64\` / `RimPy_Windows\` | mod 加载顺序与依赖验证 | GUI 启动 | 2026-10-09 |
| Audacity（绿色版） | `D:\toolbox\辅助工具\audacity-win-3.7.7-64bit\Audacity.exe` | 音频编辑（当前工程无音频需求） | 直接运行 exe | 2026-10-09 |

## E. 发布与校验（主用：`pc-release-clerk` / `pc-orchestrator`）

| 工具 | 位置 | 用途 | 调用方式 | 最后验证 |
|---|---|---|---|---|
| git **2.55.0** | PATH | 版本控制 / 变更溯源（GATE-DELTA 基线） | `git` | 2026-10-09 |
| **GATE-DELTA 校验器** | `C:\Users\Administrator\.codebuddy\skills\RimWorld工程架构规范\scripts\gate-runner.ps1` | 变更标注 ⟷ git diff 互含校验 + 调试残留扫描 | `pwsh <path> -Base HEAD -Annotation <标注> -ExcludeFromFile <清单> -Blocking`（本仓全未跟踪 ⇒ 必须带 `-ExcludeFromFile`） | 2026-10-09 |
| 集群审计 / 路由 / 回归 | `.codebuddy\audit\route-task.ps1` · `audit-subagents.ps1` · `route-task.tests.ps1` | 派发门禁、确定性路由、路由回归 | 各脚本 `-Blocking`（BLOCKED/UNROUTED ⇒ 退出码 2/3） | 2026-10-09 |
| **文档落点门禁** | `.codebuddy\audit\doc-guard.ps1` + 基线 `.codebuddy\audit\doc-baseline.json` | 文档域门禁（C1–C6：落点/增量/front-matter/索引/取代/相似度）；冻结存量、只拦新增 | `pwsh .codebuddy\audit\doc-guard.ps1 -Blocking`（`-Strict` 升级 WARN；`-Find <主题>` 存量检索；`-ExcludeFromFile` 声明范围外；**基线刷新仅在存量收口轮次**） | 2026-10-09 |
| **规范副本同步** | `C:\Users\Administrator\.codebuddy\skills\RimWorld工程架构规范\scripts\sync_from_docs.ps1` | docs 主副本 → skill `references/` 同步（SHA256 校验 + 规则引用 lint；**先比对后覆盖**，禁单向盲覆盖） | `pwsh <path> -Source "<工程根>\docs\设计文档\架构"`（以 `Hash check` + lint 输出为准） | 2026-10-09 |
| steamcmd | `D:\toolbox\steamcmd` | Workshop 上传（备选路径；主路径为游戏内 DevMode） | `steamcmd +login ... +workshop_build_item ...` | 2026-10-09 |

## F. agent → 主用工具映射

| agent | 主用工具（详见上表） |
|---|---|
| `pc-orchestrator` | `route-task.ps1` · `audit-subagents.ps1` · `gate-runner.ps1` |
| `pc-arch-gatekeeper` | cecil-dump · ilspycmd · `_research\vanilla\Assembly-CSharp` |
| `pc-data-steward` | `_research\vanilla\Assembly-CSharp` · dnSpyEx · `dotnet test` |
| `pc-ui-loc-guard` | 预览 HTML + chrome-devtools MCP · Python/Pillow · VS Code |
| `pc-compat-auditor` | dnSpyEx · cecil-dump · `_research\vanilla\Assembly-CSharp` |
| `pc-perf-tester` | `compile_with_sdk.ps1` · `deploy-to-game.ps1` · `dotnet test` · `_scripts\audit_*.ps1` |
| `pc-release-clerk` | git · `gate-runner.ps1` · `doc-guard.ps1` · steamcmd |

## G. 已知漂移与待办（以本册为准）

1. **HTML 手册（2026-09-10）两处路径已被实测推翻**：dnSpyEx 手册记 `D:\toolbox\dnSpyEx` ⇒ 实测 `D:\toolbox\辅助工具\dnSpyEx\`；.NET SDK 手册记 `C:\dotnet8` ⇒ 实测生效值 `D:\toolbox\dotnet\sdk\8.0.424`。**以本册为准**（手册属人向资产，未同步修改）。
2. **Dubs Performance Analyzer**（Steam `2038874626`，游戏内补丁耗时/Tick/GC 面板）：手册标"待订阅"，本册沿用该状态；订阅后需回填本节。
3. 本册**不登记**：CodeBuddy 内置 skill / MCP（见手册 §3）、`_scripts` 全量脚本清单（50+，按需 `list_dir`）、`memory/*.md` 中的工具教训（指针已在 B/C 类给出）。
