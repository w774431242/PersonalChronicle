---
name: agent-cluster-frontdoor
description: 强制在 PersonalChronicle（RimWorld 1.6 mod）工程中对非平凡工程任务走内置 agent 集群（pc-orchestrator 总控 + 6 个 Gate 子 agent）的前置路由与派发协议，修复“集群从未被触发”的缺口。
alwaysApply: true
---

# Agent 集群前置路由（Front-door）

本工程内置子 agent 集群（`.codebuddy/agents/`）：`pc-orchestrator`（总控/裁决）+ `pc-arch-gatekeeper`(ARCH) / `pc-data-steward`(DATA,SAVE) / `pc-ui-loc-guard`(UI,LOC) / `pc-compat-auditor`(COMP) / `pc-perf-tester`(PERF,TEST) / `pc-release-clerk`(REL,DELTA)。

**问题根因**：集群此前从未触发，是因为缺少「前置路由」这道硬门禁——没有任何机制在任务开始时就加载工程规范 skill 并派发 agent。规范本身也写明触发词“只是语义锚点，不构成强制路由”。本规则补齐该缺口。

## 触发范围
满足以下任一的**非平凡**任务（单行 typo、纯问答除外）：
- 改动涉及 `Source/`、`Defs/`、`Patches/`、`Languages/`、`About/`、`Textures/`；
- 关键词命中：新功能 / 新增 / 需求变更 / 重构 / 多模块改动 / 端到端交付 / 接入 / 兼容 / 发版 / 存档 / 持久化 / 性能 / 测试 / UI / 本地化 / 第三方 Mod。
- **强制触发词（硬开关，无条件）**：任务文本含「**启用标准化agent集群**」⇒ 无论是否命中上述关键词，一律立即执行前置协议并派发 `pc-orchestrator`（总控）统一分发，不得静默跳过。

## 前置协议（每次命中范围的任务必须执行）
1. **加载规范**：调用 `use_skill('RimWorld工程架构规范')`，按其「子 agent 集群触发」节执行。
2. **确定性路由**：把任务写到临时文件，运行
   `pwsh .codebuddy/audit/route-task.ps1 -TaskFile <tmp.txt> -JsonOut <tmp.json>`
   读取 `decision.parallel` 作为候选。
3. **语义兜底**：主 Agent 同时按各 agent 的 `description` / `TRIGGER_KEYWORDS` 自主判断（LLM 为权威；脚本仅作可复现校验）。
4. **门禁**：派发任何 Gate agent 前，运行 `pwsh .codebuddy/audit/audit-subagents.ps1 -Blocking`；`BLOCKED` 时**不得派发**，先修 agent。
5. **派发**：通过 `task` 工具以 `subagent_name` + `subagent_path`（见 `.codebuddy/agents/*.md` 顶部）调用路由结果；多 Gate 并行。
6. **UNROUTED / 多模块 / 新功能 / 重构 ⇒ 默认 `pc-orchestrator`**（总控统一分发，不得静默放行）。
7. **终检**：交付前由总控跑 `pwsh <skill>/scripts/gate-runner.ps1 -Base origin/main -Annotation <变更标注> -Blocking` 做 GATE-DELTA。

## 禁区
- 不得跳过集群直接编写本应由 Gate agent 拥有的跨模块业务代码；
- 无 Evidence 不得给出 PASS；不得伪造 PASS（GOV-012）。

## 诊断要点（若仍不触发）
若某次任务未走集群，检查：① 是否命中上方「触发范围」；② 是否漏了 `use_skill` + `route-task.ps1` 两步；③ `audit-subagents.ps1` 是否处于 BLOCKED（会阻止派发）。
