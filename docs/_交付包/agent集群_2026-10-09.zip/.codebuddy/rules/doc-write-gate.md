---
name: doc-write-gate
description: 强制在 PersonalChronicle 工程中「文档类文件落盘前」先走 DOC-003 存量检索与 DOC-004 用户审批门；禁止私自新建文档、禁止仓库根与 docs 顶层散落、禁止同主题另建并列文件。修复「AI 私自建文档、不提交用户审核、已有文档不更新继续新建」的缺口。
alwaysApply: true
---

# 文档落盘前置门（DOC Write Gate）

本规则作用于**写入动作前**（不是任务入口）；与 `agent-cluster-frontdoor.md`（任务入口路由）**作用点不同、并行生效**。
规范正本：[DOC-001–DOC-010](../../docs/设计文档/架构/12-文档与交付物治理规范.md)；操作手册：`.codebuddy/skills/doc-standard/SKILL.md`。

## 触发范围

任何**新建或覆盖**以下类型的文件前（`write_to_file` / `replace_in_file` / 脚本落盘均算）：

- `*.md` / `*.html` / `*.txt` 文档与交付物文本；
- `docs/**`、`.codebuddy/skills/**`、`.codebuddy/rules/**`、`.codebuddy/agents/**`、`系统中心蓝图/**` 下的文本资产；
- Changelog、方案、报告、验收清单、指导手册、README 索引。

## 前置门（必须依次执行，缺一不可）

1. **检索存量**（DOC-003）：先跑 `pwsh .codebuddy\audit\doc-guard.ps1 -Find <主题词>`，或用文件名/标题/索引检索；
   命中同主题存量 ⇒ **默认更新该文档**（文内迭代 + 变更历史段），不得另建新文件。
2. **提交申请**（DOC-004）：确需新建时，先在回复中输出「文档变更申请」（拟路径 / 类型 / 理由 / 存量检索结论与候选对比 / 旧件处置 / 索引登记点），
   **等待用户明确通过**；未通过之前只能产出会话内文本，**不得写文件**。
3. **落点与索引**（DOC-001/006）：路径必须命中 `docs/README.md` 用途判定表；落盘当日登记主题 README。
4. **自检**（DOC-010）：落盘后跑 `pwsh .codebuddy\audit\doc-guard.ps1 -Blocking`，不得有 BLOCKED。

## 例外（无需重复审批）

- 对**已获批准**文档的正文更新（改内容、改错字、补章节）；
- 既有文档的**移动/归档**（属 DOC-007 处置动作，但仍须登记）；
- `.codebuddy/audit/gate-records/**`（Gate 证据）· `.codebuddy/doc-journal/**`（申请留痕）· `.codebuddy/memory-journal/**`（记忆）· `.codebuddy/tmp/**`（临时）；
- 变更标注 `变更标注_CHG-*.md`（落点固定为 `docs/设计文档/架构/变更标注/`，按 GATE-DELTA 流程生成）。

## 禁区（命中即视为违规，按 GOV-012 处理）

- 未提交申请或未获通过就落盘新文档（先写后报）；
- 在**仓库根**或 **`docs/` 顶层**新建文档类文件；
- 同主题另建 `v2`/`v0.4`/`新建副本` 等并列文件而不登记取代关系；
- 以"顺手记一下/顺手建个文档"为由跳过本门；
- 用刷新 `.codebuddy/audit/doc-baseline.json` 基线的方式让违规文档"变成存量"（基线刷新仅限存量收口轮次，经用户确认）。
