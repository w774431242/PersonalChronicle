---
name: change-report
description: >-
  Generates a concrete, diff-level change report after a code modification —
  "what files/functions/lines changed, what the actual diff is, and why".
  Unlike the sibling `summarize` skill (which captures long-term project-state
  value), this skill produces a traceable modification receipt: per-file hunk
  listings, key diff snippets, change motives, and regression/impact checks.
  Trigger words include "修改报告"/"改了什么"/"change report"/"diff report"/
  "改动清单", but it can also be invoked after any edit to produce the receipt.
  Routes by engineering impact (not line count) into A 类 (single-file/small)
  or B 类 (multi-module) report, reusing the same grading as `summarize`.
---

# 具体修改报告（Change Report Router）

本技能是 `summarize` 技能的**具体版补充**：`summarize` 关注"项目状态长期变化"，
本技能关注"本次到底改了哪些文件、哪些函数、哪些行、实际 diff 是什么、为什么改"。

核心思想：每次代码修改都应留下一份**可追溯凭据**——让开发者/PM 不读 git diff
也能在 30 秒内确认"动了哪里、动了什么、有没有坑"。以**实际代码 diff** 为准。

## 触发时机

- 用户说"修改报告""改了什么""出一份改动清单""change report""diff report"等。
- 一次编辑/提交/多文件改动后，用户要求凭据式复盘。
- 与 `summarize` 的区别：本技能**不自动触发**（避免与 summarize 重复），
  仅在用户显式要求"具体改动报告"时调用；若任务结束已自动跑 summarize，
  本技能可作为按需的"展开 diff 细节"补充。

不触发：纯问答、纯检索、未产生代码变化的会话。

## 路由规则（先判断，再执行）

复用 `summarize` 的工程影响度判定（架构 × 数据 × 依赖 × 兼容 × 扩展），
但输出内容改为**文件/函数/hunk 级 diff 凭据**。

### LEVEL 1 — 单文件/单函数/小批量 → 用 A 类（具体修改清单）

满足大部分条件时使用：
- 修改文件少（≤3）、单一模块、单一功能
- 局部 Bug 修复 / UI 微调 / 参数调整 / 配置修改 / 小型重构
- 不改变公共 API、核心数据结构、模块边界、存档格式

重点输出：`改动清单（文件:行号 函数 增/删/改）+ 关键 diff 片段 + 动机 + 影响 + 验证`。
模板见 `references/A-change-receipt.md`。

### LEVEL 2/3 — 多文件/跨模块/架构改动 → 用 B 类（跨模块修改报告）

满足**任意重要条件**时升级：
- 跨多个模块修改 / 大规模重构 / 新增系统
- 改变模块职责 / 依赖关系 / 公共 API / 核心数据结构 / 存档格式
- 引入新架构模式 / 大量代码迁移

重点输出：`逐模块改动清单 + 依赖影响图 + 关键 diff 片段 + 设计决策 + 回归面`。
模板见 `references/B-change-report.md`。

升级原则与 `summarize` 一致：改 10 行但动核心 API → 按大体量；
改 500 行 UI 但单文件 → 按小体量。

## 执行步骤

1. 用 `git diff` / `git status` / 文件读取确认本次任务的**实际 diff**
   （新增 / 修改 / 删除文件，真实代码变化，含行号与 hunk）。
2. 判定 LEVEL 1 或 LEVEL 2/3。
3. 加载对应 reference 文件作为输出模板。
4. 以**当前实际代码状态**填充模板：逐项列出文件:行号:函数 的增/删/改，
   并对每处重要改动贴 `old → new` 关键 diff 片段（单片段 ≤15 行）。
5. 标注每处改动动机（关联需求/bug/规范条款 ID）。
6. 若改动涉及 UI/Data/Save/Harmony，引用对应规则 ID（ARC-/UI-/SAVE-/COMP-/AI-）。

## 与架构规范联动

- 改动若修复了某规范违规，明确写"修复 X 违规（规则 Y）"。
- 改动若违反规范红线，明确标红并给修复建议（不擅自扩大范围，仅提示）。

## 与子 agent 集群联动（本工程内置）

本 skill 的产物即 `GOV-013` 要求的**变更标注（开发者向精确改动清单）**，在集群分工中归属
**`pc-release-clerk`（`GATE-DELTA`）**：

- 产物必须满足 `assets/change-annotation-template.md` 的 **YAML front matter + 表格双段一致**，否则 `GATE-DELTA = BLOCKED`，**阻止 Release，不得绕过**。
- 交付前必须由 `pc-release-clerk` 跑客观校验（唯一 oracle）：
  `pwsh <skill>\scripts\gate-runner.ps1 -Base origin/main -Annotation <标注.md> -Blocking`。
- 本 skill 的 A 类/B 类分档与 `summarize` 一致；但 **Changelog 归 `summarize`/发布流程，本 skill 只管精确改动凭据**。
- 归属确认：`pwsh .codebuddy/audit/route-task.ps1 -Skill change-report`。

## 质量红线（两类通用）

- 不输出思考过程、不重复任务要求、不编造测试结论。
- 优先级：**实际代码 diff > 任务描述 > 推测**。
- 贴 diff 片段必须来自真实文件内容，禁止凭记忆重写。
- 没有修改的模块不写；没有发现的问题明确写"无"。
- 最终报告必须以当前实际代码状态为准。
- 禁止把"应该可以"写成"已验证"。
