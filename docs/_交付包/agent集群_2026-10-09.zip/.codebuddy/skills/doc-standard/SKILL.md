---
name: doc-standard
description: >-
  文档与交付物治理规范（PersonalChronicle agent 集群适配版）。当任务涉及**新建文档 / 写文档 / 更新文档 /
  出一份报告 / 写方案 / 补设计文档 / 文档落点 / 文档索引 / 变更标注归档 / 文档治理**时使用。
  强制执行五大铁律：①新建必须先提交「文档变更申请」并获用户明确通过（严禁先写后报）；
  ②更新优先（先检索存量，命中即更新，新建须举证）；③落点唯一（按 docs/README 判定表，仓库根与 docs 顶层禁散落）；
  ④索引同步（当日登记主题 README）；⑤取代必须登记（禁止双源并存）。
  规范正本见 DOC-001~DOC-010（docs/设计文档/架构/12-文档与交付物治理规范.md）。
  集群归属 pc-release-clerk（与 memory-standard 同构的横切规范，**非独立 Gate**）。
---

# 文档与交付物治理规范（doc-standard）

本 skill 是本工程 [DOC-001–DOC-010] 的**执行侧操作手册**：规范正本（条款 / 判定 / 证据）在
`docs/设计文档/架构/12-文档与交付物治理规范.md`；本 skill 只放「怎么操作 + 用什么工具 + 找谁归属」。

> **边界**：本 skill 管**文档与交付物文本**的产出纪律。不管记忆（→ `memory-standard`）、
> 不管变更总结的内容（→ `summarize`）、不管 diff 凭据（→ `change-report`）。四者互不替代。

## 铁律（任何文档写入前必读）

### 铁律一：先审批，后落盘（DOC-004）
- 任何**新建**文档动作，必须先产出「**文档变更申请**」并向用户完整展示，等待明确「通过」；
  用户未说「通过 / OK / 可以 / 就这样」之前，**不得写入任何文件**（会话内文本输出不受限）。
- 用户三选一：**通过 / 修改后通过 / 丢弃**。
- 通过的申请条目写入 `.codebuddy/doc-journal/<YYYY-MM-DD>/committed/`；未通过写 `pending/` 后丢弃。
- **严禁"先写后报"**。此规则与 `memory-standard` 同源（[GOV-012]），优先级高于"顺手建一个"的冲动。

### 铁律二：更新优先（DOC-003）
- 新建前必须**先检索存量**：主题词 / 文件名 / `README` 索引 / 主题子目录。
  工具：`pwsh .codebuddy\audit\doc-guard.ps1 -Find <主题词>`。
- 命中同主题存量 ⇒ **默认更新**（文内迭代 + 变更历史段）；确需新建 ⇒ 必须在申请中举证
  "为何不能并入"，并列出全部候选存量文档与逐条理由。

### 铁律三：落点唯一（DOC-001/002）
- 一切文档按 `docs/README.md` §命名规范 用途判定表落位；**仓库根与 `docs/` 顶层禁止散落**。
- 变更标注（`变更标注_CHG-*.md`）落点 = `docs/设计文档/架构/变更标注/`。
- 命名沿用 [BASE-013]：`A-创建日期-功能`；日期取创建日，迭代不改名；`doc-id` 跨迭代不变。

### 铁律四：索引同步（DOC-006）
- 新增文档**当日**登记：主题子目录 `README.md`（无则 `docs/README.md`）；规范分册同步 `docs/设计文档/架构/README.md`。
- 未被任何索引提及 ⇒ 视为**未交付**。

### 铁律五：取代必须登记（DOC-007/008）
- 新件取代旧件 ⇒ 旧件当日归档或加"已被取代"横幅并移出索引入口；**禁止双源并存**。
- 同主题版本演进**默认文内迭代**（变更历史段），不建 `v0.3`/`v0.4` 并列文件；例外须按 DOC-004 申请。

## 写入协议（标准流程）

```text
1. 检索存量（doc-guard -Find）        → 得候选清单
2. 判定：更新 or 新建？
   ├─ 更新 → 直接改存量正文 + 变更历史段 → 跳 5
   └─ 新建 → 继续
3. 出「文档变更申请」（见下方模板）    → 向用户展示
4. 用户通过 → 落盘正文（带 front-matter 六字段）→ 写 committed 申请条目
5. 登记索引（当日）                    → 取代时处置旧件
6. 跑 doc-guard -Blocking 自检         → 无 BLOCKED
7. 规范类改动 → 跑 sync_from_docs.ps1 -Source docs/设计文档/架构 → EXITCODE=0
```

### 文档变更申请模板（最小要素）

```text
【文档变更申请】
拟路径：docs/设计文档/<...>/<文件名>.md
类型：new | supersede（取代 <旧路径>）
doc-id：DOC-<域>-<YYYYMMDD>-<slug>
理由：<为什么需要这份文档>
存量检索：<命令 + 命中结果>；候选对比：<文档A：不能并入因为...>
旧件处置：<归档 / 加横幅 / 不适用>
索引登记点：<主题 README 路径>
front-matter：doc-id / status / supersedes / approved / author 齐备
```

### front-matter 六字段（DOC-005）

```text
doc-id:      DOC-<域>-<YYYYMMDD>-<slug>
status:      new | update | supersede
supersedes:  <旧文档相对路径 或 —>
approved:    <YYYY-MM-DD HH:MM>     # 用户通过审批的时间
author:      AI(<模型名>) / <用户名>
```

## 门禁与工具

| 工具 | 位置 | 用途 |
|---|---|---|
| `doc-guard.ps1` | `.codebuddy\audit\doc-guard.ps1` | 文档域门禁 C1–C6（落点 / 增量 / front-matter / 索引 / 取代 / 相似度）；`-Blocking` 违规退出码 2 |
| 基线 | `.codebuddy\audit\doc-baseline.json` | 文件系统快照（路径 + 哈希），**冻结存量、只拦新增**；刷新仅限存量收口轮次（DOC-010） |
| 申请留痕 | `.codebuddy\doc-journal\<YYYY-MM-DD>\` | `pending/` 草稿 → 用户通过 → `committed/` |
| 双副本同步 | skill `RimWorld工程架构规范\scripts\sync_from_docs.ps1` | docs 主副本 → skill references（先比对后覆盖 + SHA256 + lint） |

## 与子 agent 集群联动（本工程内置）

本工程有子 agent 集群 `.codebuddy/agents/`（总控 `pc-orchestrator` + 6 个 Gate agent）。

- **归属**：`pc-release-clerk`（`GATE-REL` / `GATE-DELTA`）。
- **定位**：**不是第 11 道 Gate**——10 道 Gate 归属不变；文档域验收并入 `GATE-DELTA`（变更标注互含）
  与 `doc-guard.ps1`（落点与增量门禁）两条既有通道。
- **前置门**：`.codebuddy/rules/doc-write-gate.md`（alwaysApply，作用于"写入动作前"）；
  与 `agent-cluster-frontdoor.md`（作用于"任务入口"）作用点不同、并行生效。
- 归属确认：`pwsh .codebuddy/audit/route-task.ps1 -Skill doc-standard`。
- 集群审计：`pwsh .codebuddy/audit/audit-subagents.ps1 -Blocking`。

| 相邻 skill | 产物 | 边界 |
|---|---|---|
| `summarize` | 变更总结 | 内容规则归 summarize；其**落盘**受 DOC-004 约束 |
| `change-report` | diff 级凭据 | 同上；变更标注落点由 DOC-001 固定 |
| `memory-standard` | 记忆条目 | 记忆落 `.codebuddy/memory-journal/`，**不是文档** |
