# doc-standard · schema 与模板

字段取值字典 + 申请/落点/取代模板。规范正本见 `docs/设计文档/架构/12-文档与交付物治理规范.md`。

## 1. front-matter 字段字典

| 字段 | 必填 | 取值 | 说明 |
|---|---|---|---|
| `doc-id` | 是 | `DOC-<域>-<YYYYMMDD>-<slug>` | 稳定，跨迭代不变；域取功能域缩写（如 `GOV` / `MFG` / `ECON`） |
| `status` | 是 | `new` / `update` / `supersede` | 本次落盘性质 |
| `supersedes` | 是 | 旧文档相对路径 或 `—` | `status=supersede` 时不得为 `—` |
| `approved` | 是（新建） | `YYYY-MM-DD HH:MM` | 用户通过审批的时间；更新既有文档可保留原值 |
| `author` | 是 | `AI(<模型名>)` / `<用户名>` | 产出者署名（DOC-010） |
| `reviewed` | 否 | `YYYY-MM-DD`（用户复核日） | 交付后由用户补填 |

## 2. 落位判定表（与 `docs/README.md` §命名规范 0 同源）

| 用途 | 目录 | 判定 |
|---|---|---|
| 设计 / 方案 / 规范 / 功能设计 | `docs/设计文档/` | 规范契约 → `架构/`；跨模块方案 → `方案/`；子系统设计 → `功能模块/<子系统>/` |
| 变更标注 | `docs/设计文档/架构/变更标注/` | 新件唯一落点；仓库根存量冻结只读 |
| 缺陷与测试问题 | `docs/问题跟踪/` | 待修清单、实机测试过程日志 |
| 专项审计证据 | `docs/设计文档/功能模块/<子系统>/` | 跟随被审对象；确无所属 → `设计文档/架构/` |
| 开发辅助 | `docs/开发参考/` | 代码索引、项目清单、工具手册、分析报告 |
| 玩家文档 | `docs/面向玩家/` | 面向玩家的手册与说明 |
| UI 预览 mockup | `docs/UI预览/` | 一切 `*.html` 交互预览 |
| 版本变更日志 | `docs/changelog/` | 按版本归档 |
| 外部游戏资料 | `docs/参考清单/` | RimWorld API/机制资料 |
| 历史过程文档 | `docs/_归档/` | 只进不出，不再作为检索入口 |

**禁止**：仓库根、`docs/` 顶层（`README.md` 除外）新建任何文档类文件。

## 3. 文档变更申请模板

```text
【文档变更申请】
拟路径：docs/设计文档/<...>/<文件名>.md
类型：new | supersede（取代 <旧路径>）
doc-id：DOC-<域>-<YYYYMMDD>-<slug>
理由：<为什么需要这份文档；解决什么问题>
存量检索：<命令或检索词 + 命中结果>
候选对比：<文档A：不能并入因为 ...；文档B：不能并入因为 ...>
旧件处置：<归档到 _归档/ | 加"已被取代"横幅 | 不适用>
索引登记点：<主题 README / docs/README.md 路径>
```

## 4. 取代处置模板（旧件横幅）

```markdown
> ⚠ **已被取代（<YYYY-MM-DD>）**：本文档由 [<新文档名>](<相对路径>) 取代，仅作历史留档。
> 新件：<相对路径>；取代原因：<一句话>。
```

处置二选一：**移入同级 `_归档/`**（全局存档用 `docs/_归档/`）或**加横幅并移出索引入口**。

## 5. 检索工具（doc-guard）

```powershell
pwsh .codebuddy\audit\doc-guard.ps1 -Find 经济      # 存量主题检索（DOC-003 第一步）
pwsh .codebuddy\audit\doc-guard.ps1                 # 报告模式（只出结论，退出码 0）
pwsh .codebuddy\audit\doc-guard.ps1 -Blocking       # 违规退出码 2（交付终检）
pwsh .codebuddy\audit\doc-guard.ps1 -Strict         # WARN 升级为 BLOCKED
pwsh .codebuddy\audit\doc-guard.ps1 -Rebaseline     # 刷新基线（仅存量收口轮次，需用户确认）
pwsh .codebuddy\audit\doc-guard.ps1 -Blocking -ExcludeFromFile <清单>   # 声明范围外（并行在途/预存无关改动）
```
