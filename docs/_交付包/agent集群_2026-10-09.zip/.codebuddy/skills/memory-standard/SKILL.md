---
name: memory-standard
description: >-
  记忆标准化规范（本工程 agent 集群适配版）。当用户要求记录、保存、记住任何信息
  （偏好、约定、决策、代码改动、临时上下文），或任何需要把内容写入"记忆"的动作时使用。
  强制执行四大铁律：①写入前必须提交用户审核（pending→committed，严禁先写后报）；
  ②当日记忆文件夹归集；③结构化字段（时间精准到分钟 / 代码层 / 功能归属 / 类型 / 内容 / 有效期）；
  ④长短期分离。触发词/场景：记忆标准化、写记忆、记住这个、保存偏好、记一下、记到记忆、
  把它加到记忆、长期记/短期记。本 skill 替代向扁平 MEMORY.md 直接追加；
  集群归属 pc-release-clerk（GATE-REL / GATE-DELTA），路由见下方"与子 agent 集群联动"。
---

# 记忆标准化规范（memory-standard）

本 skill 定义本工程 agent 集群内**一切记忆写入动作**的统一规范。目标：杜绝把记忆无结构地塞进单个 `MEMORY.md`，改为**先审核后写入、当日归集、字段结构化、长短期分离**。

> **双头演进声明**：本文件是 `C:\Users\Administrator\.workbuddy\skills\memory-standard` 的**集群适配版**（工程内副本）。两版各自演进，**禁止单向覆盖同步**——回写任一侧前必须先逐条比对差异（源↔副本），否则后加条款会被静默丢失。本版相对原版的差异仅三处：① 记忆落点 root 改为工程内推导；② 新增「与子 agent 集群联动」节；③ 工具脚本默认 root 改为按脚本位置推导。

## 铁律（任何记忆写入前必读）

### 铁律一：先审核，后写入
- 任何"写入记忆"动作，**必须先生成草稿条目并向用户完整展示，等待用户明确"通过"**；用户未说"通过/OK/可以/记吧"之前，不得写入 `committed/`。
- 用户对每条目三选一：**通过 / 修改后通过 / 丢弃**。
- 草稿存放 `<root>/<YYYY-MM-DD>/pending/`；通过后移动到 `committed/`。
- **严禁"先写后报"**。本规则优先级高于"顺手记一下"的冲动。

### 铁律二：当日记忆文件夹归集
- 每条记忆归入"当日记忆文件夹"：`<root>/<YYYY-MM-DD>/`。
- 首次写入当天记忆前，先运行 `python scripts/scaffold_day.py <root> <today>` 建好 `pending/`、`committed/` 子目录与当日索引 `index.md`。
- `<root>` 默认：`<工程根>/.codebuddy/memory-journal/`（脚本按自身位置自动推导；可用 `--root` / 首参覆盖）。

### 铁律三：结构化字段（每条必含，缺任一则 `validate_entry.py` 报错）

> **字段行格式（机器解析契约，勿改）**：`- 字段名: 值` —— 连字符 + 空格 + 字段名 + **半角冒号** + 空格 + 值。
> **不得加粗、不得用全角冒号**：`- **时间**：xxx` 会被解析为字段名 `**时间**` ⇒ 六个必填字段全部判定缺失（2026-10-09 实测踩坑）。

- **时间**：`YYYY-MM-DD HH:MM`（24 小时制，精准到分钟，本地时区）。
- **代码层**：枚举之一 —— `UI` / `翻译` / `SQL` / `后端` / `前端` / `测试` / `构建` / `文档` / `通用`。非代码类记忆填 `通用`。RimWorld Mod 语境补充约定：`UI` 含游戏内窗口/组件/HUD；`翻译` 含 Languages XML / Keyed；`构建` 含编译脚本 / 部署 / CI；`文档` 含规范与预览 HTML。
- **功能归属**：该代码层内的具体归属，如 `登录按钮点击事件`、`user 表索引优化`、`key=settings.title 英文文案`；Mod 语境如 `Defs/ProfessionalSkills.xml`、`ITab_Pawn_Career.Overview`。非代码填 `—`。
- **类型**：`长期` 或 `短期`。
- **内容**：一句话描述记忆要点。
- **有效期**：仅短期填，格式 `until:YYYY-MM-DD`；长期不填。
- **审核状态**：`待审核`(pending) / `已通过@<时间>`(committed)。

### 铁律四：长短期分离
- **长期**：跨会话稳定有效的偏好/约定/事实，无有效期，永久保留（除非用户显式作废）。
- **短期**：临时上下文、单次任务状态、易过期信息，**必须带 `until`**；超过有效期者检索时自动排除。

## 写入协议（标准流程）

1. 收集信息 → 在脑中/草稿区组成条目（**不要直接写文件**）。
2. `python scripts/scaffold_day.py` 确保当日文件夹存在（root 自动推导，可用 `--root` 覆盖）。
3. 将草稿写入 `<root>/<today>/pending/<HHMM>-<slug>.md`，含全部字段，审核状态=待审核。
4. **向用户展示该条目全文**，并请其确认（通过 / 修改 / 丢弃）。
5. 用户通过后：将文件移动到 `committed/`，把审核状态改为 `已通过@<时间>`，并在 `<root>/<today>/index.md` 追加一行索引。
6. 用户要求修改 → 回到步骤 3；要求丢弃 → 删除 pending 文件，不进 committed。

## 与子 agent 集群联动（本工程内置）

本工程有子 agent 集群 `.codebuddy/agents/`（总控 `pc-orchestrator` + 6 个 Gate agent）。
本 skill 的产物属**记录/留档侧的长期资产**，在集群分工中归属 **`pc-release-clerk`（`GATE-REL` / `GATE-DELTA`）**：

- 记忆条目的"先审核后写入"门禁与 `GATE-DELTA` 的留痕纪律同源：**没有用户确认 ⇒ 不得落 `committed/`**，与"没有变更标注 ⇒ GATE-DELTA 一律 BLOCKED"同一原则。
- 归属确认：`pwsh .codebuddy/audit/route-task.ps1 -Skill memory-standard`。
- 集群审计：`pwsh .codebuddy/audit/audit-subagents.ps1 -Blocking`（本 skill 已登记注册表，覆盖检查失败即 BLOCKED）。

**与相邻 skill 的边界（三者互不替代）**：

| skill | 产物 | 性质 | 归属 |
|---|---|---|---|
| `summarize` | 变更总结（A 类 / B 类） | 本次任务的项目状态变化 | `pc-release-clerk` |
| `change-report` | diff 级改动凭据 | 本次任务的文件/符号/行 | `pc-release-clerk` |
| **`memory-standard`（本 skill）** | 记忆条目（长期/短期） | 跨会话稳定有效的偏好/约定/事实 | `pc-release-clerk` |
| Changelog（规范侧） | 用户向发布说明 | 版本级 | `pc-release-clerk`（GOV-013：不得与变更标注混用） |

**落点纪律**：记忆条目写入 `.codebuddy/memory-journal/`，**不得**写进 `.codebuddy/audit/gate-records/`（那是 Gate 证据），**不得**替代 `.codebuddy/memory/<date>.md` 每日日志（系统级日志仍按原规则保留）。

## 与其他记忆层的关系
- 本规范覆盖"用户/项目显式记忆"。云档案与系统自动注入的记忆层不在此列。
- **不鼓励向扁平 `MEMORY.md` 追加扁平条目**；长期偏好改走本规范"长期"类型，存于 memory-journal。
  （工程级 `MEMORY.md` 索引型记忆由宿主系统维护，本规范不接管、不覆盖。）
- 工作区 `.codebuddy/memory/` 的每日日志仍按系统规则保留，本规范不替代它。

## 工具脚本
- `scripts/scaffold_day.py [root] [YYYY-MM-DD]`：建当日文件夹骨架（pending/committed/index.md）。root 缺省时按脚本位置推导为 `<工程根>/.codebuddy/memory-journal`。
- `scripts/validate_entry.py <entry_file>`：校验单条记忆字段完整性与格式，返回 0/非 0。
- `scripts/visualize_memory.py [root] [--out file]`：扫描 journal 生成自包含 HTML 看板（纯内联 SVG，无外部 CDN），按代码层/长短期/审核状态/时间四维可视化。
- `references/schema.md`：字段取值字典 + 完整示例 + 审核话术模板。
