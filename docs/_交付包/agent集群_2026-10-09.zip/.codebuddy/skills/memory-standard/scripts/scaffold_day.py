#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""建立当日记忆文件夹骨架：<root>/<YYYY-MM-DD>/{pending,committed}/ + index.md

root 缺省按脚本位置推导为 <工程根>/.codebuddy/memory-journal
（本脚本位于 <工程根>/.codebuddy/skills/memory-standard/scripts/）。
用法: python scaffold_day.py [root] [YYYY-MM-DD]
"""
import sys
import os
from datetime import datetime

PROJ_SUBPATH = os.path.join(".codebuddy", "memory-journal")


def default_root():
    here = os.path.dirname(os.path.abspath(__file__))  # .../memory-standard/scripts
    proj_root = os.path.abspath(os.path.join(here, "..", "..", "..", ".."))
    return os.path.join(proj_root, PROJ_SUBPATH)


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else default_root()
    day = sys.argv[2] if len(sys.argv) > 2 else datetime.now().strftime("%Y-%m-%d")
    daydir = os.path.join(root, day)
    created = []
    for sub in ("pending", "committed"):
        d = os.path.join(daydir, sub)
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
            created.append(d)
    idx = os.path.join(daydir, "index.md")
    if not os.path.exists(idx):
        with open(idx, "w", encoding="utf-8") as f:
            f.write(
                f"# 当日记忆索引 {day}\n\n"
                "| 时间 | 类型 | 代码层 | 功能归属 | 审核 |\n"
                "|---|---|---|---|---|\n"
            )
        created.append(idx)
    print(f"当日文件夹就绪: {daydir}")
    for c in created:
        print("  + " + c)


if __name__ == "__main__":
    main()
