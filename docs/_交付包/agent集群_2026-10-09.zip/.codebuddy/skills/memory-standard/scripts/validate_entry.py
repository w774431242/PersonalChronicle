#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""校验单条记忆条目字段完整性与格式。返回 0=通过，1=失败，2=用法错误。"""
import sys
import os
import re

REQUIRED = ["时间", "代码层", "功能归属", "类型", "内容", "审核状态"]
CODE_LAYERS = {"UI", "翻译", "SQL", "后端", "前端", "测试", "构建", "文档", "通用"}
TYPES = {"长期", "短期"}
TIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")
UNTIL_RE = re.compile(r"^until:\d{4}-\d{2}-\d{2}$")

FIELD_RE = re.compile(r"^\s*-\s*([^:：]+)[：:]\s*(.*)$")


def parse(path):
    fields = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = FIELD_RE.match(line)
            if m:
                fields[m.group(1).strip()] = m.group(2).strip()
    return fields


def validate(path):
    if not os.path.exists(path):
        return ["文件不存在: " + path]
    fields = parse(path)
    errs = []
    for r in REQUIRED:
        if r not in fields or not fields[r]:
            errs.append(f"缺少必填字段: {r}")
    t = fields.get("时间", "")
    if t and not TIME_RE.match(t):
        errs.append(f"时间格式错误(需 YYYY-MM-DD HH:MM): {t}")
    cl = fields.get("代码层", "")
    if cl and cl not in CODE_LAYERS:
        errs.append(f"代码层取值非法(允许: {'/'.join(sorted(CODE_LAYERS))}): {cl}")
    ty = fields.get("类型", "")
    if ty and ty not in TYPES:
        errs.append(f"类型取值非法(允许: 长期/短期): {ty}")
    if ty == "短期":
        u = fields.get("有效期", "")
        if not UNTIL_RE.match(u):
            errs.append(f"短期记忆必须含有效期(until:YYYY-MM-DD)，当前: {u!r}")
    return errs


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: validate_entry.py <entry_file>")
        sys.exit(2)
    errs = validate(sys.argv[1])
    if errs:
        print("校验失败:")
        for e in errs:
            print("  - " + e)
        sys.exit(1)
    print("校验通过: 字段完整且格式合法")
    sys.exit(0)
