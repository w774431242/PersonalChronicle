#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫描 memory-journal，生成自包含 HTML 看板（纯内联 SVG，无外部依赖/CDN）。

用法:
  python visualize_memory.py [root] [--out <output.html>]
  <root> 默认: <工程根>/.codebuddy/memory-journal（按脚本位置推导）
输出: <root>/memory-dashboard.html （可用浏览器/预览面板直接打开）
"""
import sys
import os
import re
import math
import glob
from datetime import datetime
from collections import Counter, defaultdict

PROJ_SUBPATH = os.path.join(".codebuddy", "memory-journal")


def default_root():
    here = os.path.dirname(os.path.abspath(__file__))  # .../memory-standard/scripts
    proj_root = os.path.abspath(os.path.join(here, "..", "..", "..", ".."))
    return os.path.join(proj_root, PROJ_SUBPATH)

FIELD_RE = re.compile(r"^\s*-\s*([^:：]+)[：:]\s*(.*)$")

LAYER_COLORS = {
    "UI": "#4f9dff", "翻译": "#ffb14f", "SQL": "#7ee787", "后端": "#ff7b9c",
    "前端": "#a78bfa", "测试": "#f0d44b", "构建": "#5ad1c9", "文档": "#c0c8d4",
    "通用": "#8b95a5", "?": "#8b95a5",
}
TYPE_COLORS = {"长期": "#4f9dff", "短期": "#ffb14f", "?": "#8b95a5"}
STATUS_COLORS = {"committed": "#7ee787", "pending": "#f0d44b"}


def esc(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def parse(path):
    f = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            m = FIELD_RE.match(line)
            if m:
                f[m.group(1).strip()] = m.group(2).strip()
    return f


def collect(root):
    entries = []
    for status in ("committed", "pending"):
        for p in glob.glob(os.path.join(root, "*", status, "*.md")):
            parts = p.split(os.sep)
            day = parts[-3]
            e = parse(p)
            e["_day"] = day
            e["_status"] = status
            e["_file"] = p
            entries.append(e)
    return entries


def hbar(labels, values, colors, width=560, row_h=28, pad=10):
    maxv = max(values) if values else 1
    h = row_h * len(labels) + pad * 2
    svg = [f'<svg width="{width}" height="{h}" viewBox="0 0 {width} {h}" role="img">']
    y = pad
    for lab, val, col in zip(labels, values, colors):
        bw = int((width - 150) * val / maxv) if maxv else 0
        svg.append(f'<rect x="140" y="{y}" width="{max(bw,2)}" height="{row_h-9}" rx="3" fill="{col}"><title>{esc(lab)}: {val}</title></rect>')
        svg.append(f'<text x="134" y="{y+row_h/2-3}" text-anchor="end" dominant-baseline="middle" fill="#c0c8d4" font-size="12">{esc(lab)}</text>')
        svg.append(f'<text x="{140+max(bw,2)+6}" y="{y+row_h/2-3}" dominant-baseline="middle" fill="#8b95a5" font-size="11">{val}</text>')
        y += row_h
    svg.append("</svg>")
    return "".join(svg)


def donut(segments, size=170):
    total = sum(v for _, v, _ in segments) or 1
    cx = cy = size / 2
    r = size / 2 - 12
    svg = [f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" role="img">']
    if total <= 0 or all(v == 0 for _, v, _ in segments):
        svg.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#2a2f3a" stroke-width="16"/>')
    else:
        ang = -90.0
        for lab, val, col in segments:
            if val == 0:
                continue
            sweep = 360.0 * val / total
            x1 = cx + r * math.cos(math.radians(ang))
            y1 = cy + r * math.sin(math.radians(ang))
            x2 = cx + r * math.cos(math.radians(ang + sweep))
            y2 = cy + r * math.sin(math.radians(ang + sweep))
            large = 1 if sweep > 180 else 0
            svg.append(f'<path d="M {cx:.2f} {cy:.2f} L {x1:.2f} {y1:.2f} A {r} {r} 0 {large} 1 {x2:.2f} {y2:.2f} Z" fill="{col}"><title>{esc(lab)}: {val}</title></path>')
            ang += sweep
    svg.append(f'<text x="{cx}" y="{cy-2}" text-anchor="middle" fill="#e6ebf2" font-size="22" font-weight="600">{total}</text>')
    svg.append(f'<text x="{cx}" y="{cy+16}" text-anchor="middle" fill="#8b95a5" font-size="11">条记忆</text>')
    svg.append("</svg>")
    return "".join(svg)


def stacked(labels, data, cat_order, cat_colors, width=560, row_h=28, pad=10):
    # data: {label: {cat: count}}
    maxv = max((sum(d.values()) for d in data.values()), default=1) or 1
    h = row_h * len(labels) + pad * 2
    svg = [f'<svg width="{width}" height="{h}" viewBox="0 0 {width} {h}" role="img">']
    y = pad
    for lab in labels:
        d = data.get(lab, {})
        x = 140
        tot = sum(d.values())
        svg.append(f'<text x="134" y="{y+row_h/2-3}" text-anchor="end" dominant-baseline="middle" fill="#c0c8d4" font-size="12">{esc(lab)}</text>')
        for cat in cat_order:
            v = d.get(cat, 0)
            if not v:
                continue
            bw = int((width - 150) * v / maxv)
            svg.append(f'<rect x="{x}" y="{y}" width="{max(bw,2)}" height="{row_h-9}" rx="2" fill="{cat_colors.get(cat,"#8b95a5")}"><title>{esc(lab)} / {esc(cat)}: {v}</title></rect>')
            x += max(bw, 2)
        svg.append(f'<text x="{x+6}" y="{y+row_h/2-3}" dominant-baseline="middle" fill="#8b95a5" font-size="11">{tot}</text>')
        y += row_h
    svg.append("</svg>")
    return "".join(svg)


def card(num, label, color):
    return (f'<div class="card"><div class="num" style="color:{color}">{num}</div>'
            f'<div class="lab">{esc(label)}</div></div>')


def build(entries, root):
    total = len(entries)
    by_layer = Counter(e.get("代码层", "通用") for e in entries)
    by_type = Counter(e.get("类型", "?") for e in entries)
    by_status = Counter(e["_status"] for e in entries)
    by_day = Counter(e["_day"] for e in entries)

    layers = [l for l in LAYER_COLORS if l != "?" and by_layer.get(l)]
    layers.sort(key=lambda l: -by_layer[l])
    layer_vals = [by_layer[l] for l in layers]
    layer_cols = [LAYER_COLORS[l] for l in layers]

    type_seg = [("长期", by_type.get("长期", 0), TYPE_COLORS["长期"]),
                ("短期", by_type.get("短期", 0), TYPE_COLORS["短期"])]
    status_seg = [("已通过", by_status.get("committed", 0), STATUS_COLORS["committed"]),
                  ("待审核", by_status.get("pending", 0), STATUS_COLORS["pending"])]

    # layer x type stacked
    lt = defaultdict(Counter)
    for e in entries:
        lt[e.get("代码层", "通用")][e.get("类型", "?")] += 1
    stack_labels = layers if layers else ["通用"]
    stack_data = {l: lt[l] for l in stack_labels}

    # legend html
    def legend(items):
        return "".join(f'<span class="lg"><i style="background:{c}"></i>{esc(k)}</span>' for k, c in items)

    # recent entries table
    def sort_key(e):
        t = e.get("时间", "")
        return (e["_day"], t)
    rows = sorted(entries, key=sort_key, reverse=True)
    trs = []
    for e in rows:
        typ = e.get("类型", "?")
        layer = e.get("代码层", "通用")
        st = e["_status"]
        badge = ("已通过" if st == "committed" else "待审核")
        bcol = STATUS_COLORS[st]
        exp = e.get("有效期", "—")
        content = esc(e.get("内容", ""))
        if len(content) > 60:
            content = content[:60] + "…"
        trs.append(
            f'<tr><td>{esc(e.get("时间","—"))}</td>'
            f'<td><span class="pill" style="background:{TYPE_COLORS.get(typ,"#8b95a5")}33;color:{TYPE_COLORS.get(typ,"#8b95a5")}">{esc(typ)}</span></td>'
            f'<td><span class="pill" style="background:{LAYER_COLORS.get(layer,"#8b95a5")}33;color:{LAYER_COLORS.get(layer,"#8b95a5")}">{esc(layer)}</span></td>'
            f'<td>{esc(e.get("功能归属","—"))}</td>'
            f'<td>{content}</td>'
            f'<td>{esc(exp)}</td>'
            f'<td><span class="pill" style="background:{bcol}22;color:{bcol}">{badge}</span></td></tr>'
        )
    rows_html = "".join(trs) if trs else '<tr><td colspan="7" style="text-align:center;color:#8b95a5">暂无记忆条目</td></tr>'

    gen = datetime.now().strftime("%Y-%m-%d %H:%M")

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>记忆标准化看板</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#0f1320;color:#e6ebf2;font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;padding:24px}}
h1{{font-size:20px;margin:0 0 4px}}
.sub{{color:#8b95a5;font-size:13px;margin-bottom:20px}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:22px}}
.card{{background:#171c2b;border:1px solid #232a3a;border-radius:10px;padding:14px 18px;min-width:110px}}
.card .num{{font-size:24px;font-weight:700}}
.card .lab{{color:#8b95a5;font-size:12px;margin-top:2px}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}
@media(max-width:820px){{.grid{{grid-template-columns:1fr}}}}
.panel{{background:#171c2b;border:1px solid #232a3a;border-radius:10px;padding:16px}}
.panel h2{{font-size:14px;margin:0 0 12px;color:#c0c8d4;font-weight:600}}
.row{{display:flex;gap:18px;align-items:center;flex-wrap:wrap}}
.lg{{display:inline-flex;align-items:center;font-size:12px;color:#8b95a5;margin-right:12px}}
.lg i{{width:10px;height:10px;border-radius:2px;margin-right:5px;display:inline-block}}
table{{width:100%;border-collapse:collapse;font-size:12px;margin-top:6px}}
th,td{{text-align:left;padding:8px 6px;border-bottom:1px solid #232a3a;vertical-align:top}}
th{{color:#8b95a5;font-weight:500}}
.pill{{padding:2px 8px;border-radius:20px;font-size:11px;white-space:nowrap}}
.section{{margin-top:16px}}
</style></head>
<body>
<h1>记忆标准化看板</h1>
<div class="sub">数据源：{esc(root)} ｜ 生成时间：{gen} ｜ 共 {total} 条记忆</div>

<div class="cards">
{card(total,"总记忆", "#e6ebf2")}
{card(by_type.get("长期",0),"长期", TYPE_COLORS["长期"])}
{card(by_type.get("短期",0),"短期", TYPE_COLORS["短期"])}
{card(by_status.get("committed",0),"已通过", STATUS_COLORS["committed"])}
{card(by_status.get("pending",0),"待审核", STATUS_COLORS["pending"])}
{card(len(by_day),"覆盖天数", "#5ad1c9")}
</div>

<div class="grid">
  <div class="panel">
    <h2>代码层分布</h2>
    {hbar(layers, layer_vals, layer_cols)}
    <div style="margin-top:8px">{legend([(l, LAYER_COLORS[l]) for l in layers])}</div>
  </div>
  <div class="panel">
    <h2>长短期比例</h2>
    <div class="row">
      {donut(type_seg)}
      <div>{legend([(k, c) for k, _, c in type_seg])}<div style="color:#8b95a5;font-size:12px;margin-top:8px">长期 = 跨会话稳定有效<br>短期 = 带有效期，过期自动排除</div></div>
    </div>
  </div>
  <div class="panel">
    <h2>代码层 × 类型（堆叠）</h2>
    {stacked(stack_labels, stack_data, ["长期","短期"], TYPE_COLORS)}
  </div>
  <div class="panel">
    <h2>审核状态</h2>
    <div class="row">
      {donut(status_seg)}
      <div>{legend([(k, c) for k, _, c in status_seg])}<div style="color:#8b95a5;font-size:12px;margin-top:8px">待审核 = 仍在 pending/ 等待你确认</div></div>
    </div>
  </div>
</div>

<div class="panel section">
  <h2>全部记忆条目（按时间倒序）</h2>
  <table>
    <thead><tr><th>时间</th><th>类型</th><th>代码层</th><th>功能归属</th><th>内容</th><th>有效期</th><th>审核</th></tr></thead>
    <tbody>{rows_html}</tbody>
  </table>
</div>
</body></html>"""
    return html


def main():
    args = sys.argv[1:]
    out = None
    if "--out" in args:
        i = args.index("--out")
        out = args[i + 1] if i + 1 < len(args) else None
        del args[i:i + 2]
    root = args[0] if args else default_root()
    if out is None:
        out = os.path.join(root, "memory-dashboard.html")
    if not os.path.isdir(root):
        print("记忆根目录不存在: " + root)
        sys.exit(2)
    entries = collect(root)
    html = build(entries, root)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"已生成看板: {out}")
    print(f"扫描到 {len(entries)} 条记忆（committed+pending）")


if __name__ == "__main__":
    main()
