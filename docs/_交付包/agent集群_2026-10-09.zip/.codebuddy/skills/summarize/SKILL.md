---
name: summarize
description: >-
  AUTO-TRIGGER after ANY coding/modification task completes (user need not ask).
  This skill MUST be invoked automatically whenever a programming task ends —
  bug fix, UI tweak, param/config change, small feature, local refactor, new
  system, module, architecture refactor, or cross-module work. It auto-routes
  by engineering impact (not line count) into A 类 small-change summary or
  B 类 engineering report, then outputs the matching template. Trigger words
  include "总结"/"summary"/"change summary"/"engineering report", but the skill
  runs proactively at task end even without such a request.
---

# 总结摘要（Change Summary Router）

本技能在**任何编程/修改类任务完成后自动触发**，生成一份面向长期价值的变更总结，而不是开发日志。

核心思想：AI 编程会产生大量过程文本，但真正有长期价值的是**“项目状态变化”**。
因此总结必须按**任务体量（工程影响度）**自动切换两套协议，并以**实际代码 diff** 为准。

## 触发时机（自动，无需用户请求）

本技能遵循工作流约定：**每次编程/修改类任务结束、主 Agent 准备把控制权交还用户前，
必须自动调用本技能**。触发信号包括（满足任一即触发，且用户不须显式说“总结”）：

- 完成了一次代码编辑（新增 / 修改 / 删除文件）。
- 完成了 Bug 修复、UI 调整、参数/配置修改、小功能、局部重构。
- 完成了新系统 / 模块 / 架构重构 / 跨模块改造。
- 用户说“总结”“出一份总结”“generate a summary”“engineering report”等。
- 不确定该用小总结还是大报告时（见下方路由器，由技能内部自动判定）。

不触发：纯问答、纯检索、未产生代码变化的会话。

## 路由规则（先判断，再执行）

每个任务完成后，**先判断工程影响度**，再选择协议。判断标准不是代码行数，
而是**架构影响 × 数据影响 × 依赖影响 × 兼容性影响 × 扩展性影响**。

### LEVEL 1 — 小体量变更 → 用 A 类（小体量代码变更总结协议）

满足大部分条件时使用：

- 修改文件数量较少、单一模块、单一功能
- 局部 Bug 修复 / UI 或样式调整 / 参数调整 / 配置修改 / 小型重构
- 不改变公共 API、核心数据结构、模块边界、核心架构、存档格式、主要依赖关系

重点输出：`What changed / Before → After / Impact / Verification`。
详细模板见 `references/A-small-change.md`。

### LEVEL 2 / 3 — 大体量工程行为 → 用 B 类（大体量工程化变更总结协议）

满足**任意重要条件**时升级：

- 新增完整系统 / 核心模块 / 跨多个模块修改 / 大规模重构
- 改变模块职责 / 依赖关系 / 公共 API / 核心数据结构 / 存档格式
- 建立扩展机制 / 基础设施 / 引入新架构模式 / 大量代码迁移 / 替换旧系统
- 涉及第三方 Mod / Plugin / API / 对未来扩展方式产生重大影响

重点输出：`Before → Architecture Change → Design Decision → Dependency →
Compatibility → Extensibility → Verification → Technical Debt → Project State`。
详细模板见 `references/B-engineering-report.md`。

LEVEL 3 在“同时满足多个大型条件，或影响项目长期开发方式”时强制：
必须生成 `PROJECT_STATE`、记录架构决策 / 兼容性 / 技术债务 / 下一阶段。

### 升级原则（关键）

- 一个只改 10 行但修改了核心 API 的任务，**按大体量**。
- 一个改 500 行 UI 但局限在单个 UI 的，**按小体量**。
- 若小任务进行中发现涉及公共 API / 核心数据结构 / 存档格式 / 多模块依赖 /
  核心系统重构 / 新增基础设施 / 大量文件修改，**自动升级到 B 类**。

## 执行步骤

1. 检查本次任务的实际 diff（新增 / 修改 / 删除文件，真实代码变化）。
2. 按上方路由规则判定 LEVEL 1 或 LEVEL 2/3。
3. 加载对应 reference 文件作为输出模板。
4. 以**当前实际代码状态**填充模板，严禁虚构、严禁把推测当事实、
   严禁把“应该可以”写成“已验证”。
5. 小任务：直接输出 A 类报告。大任务：输出 B 类报告（LEVEL 3 含 `PROJECT_STATE`）。
6. 如用户在本次会话已要求记入工作记忆，按 working_memory 规则追加摘要。

## 与子 agent 集群联动（本工程内置）

本工程有子 agent 集群 `.codebuddy/agents/`（总控 `pc-orchestrator` + 6 个 Gate agent）。
本 skill 的产物属**交付侧证据**，在集群分工中归属 **`pc-release-clerk`（`GATE-REL` / `GATE-DELTA`）**：

- A 类 / B 类总结 ⇒ 作为 `GATE-REL` 的 **Change Summary** 证据。
- 若本次改动同时需要「精确到文件/符号/行」的验收定位 ⇒ 补 `change-report` skill 与
  `assets/change-annotation-template.md`，由 `pc-release-clerk` 出 `GATE-DELTA` 结论。
- ⚠️ **禁止把 `Changelog`（用户向，不写行号）与变更标注（开发者向，精确到符号/行）混为一谈**（`GOV-013`：二者职责分离、互不替代）。
- 归属确认：`pwsh .codebuddy/audit/route-task.ps1 -Skill summarize`。

## 质量红线（两类通用）

- 不输出思考过程、不重复代码、不编造测试结论、不与本次无关的架构分析。
- 优先级：**实际代码变化 > 任务描述 > 推测**。
- 没有修改的模块不写；没有发现的问题明确写“无”。
- 最终报告必须以当前实际代码状态为准。
